package mindtree.playerauctionsystem.daoutil.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


import mindtree.playerauctionsystem.daoutil.DbConnectivity;
import mindtree.playerauctionsystem.exception.UtilityException;

public class DbConnectivityImpl implements DbConnectivity {
	private static final String URL="jdbc:mysql://localhost:3306/player_db?useSSL=false";
	private static final String USERNAME="root";
	private static final String PASSWORD="Welcome123";
	private DbConnectivityImpl() {
		
	}
    private static Connection connection=null;
    public static Connection getConnection() throws UtilityException {
    	if(connection ==null)
    		try {
    			Class.forName("com.mysql.jdbc.Driver");
    			connection=DriverManager.getConnection(URL, USERNAME, PASSWORD);
    		}
    	catch(ClassNotFoundException e)
    	{
    		throw new UtilityException("Something wrong with Driver check ur driver in library and version of Library",e);
    	}
    	catch(SQLException e) {
    		throw new UtilityException("something wrong with Getconnectionmethod,check your Input credentials for Sql",e);
    	}
    	return connection;
    }
}


