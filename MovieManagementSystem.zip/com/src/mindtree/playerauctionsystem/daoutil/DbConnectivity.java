package mindtree.playerauctionsystem.daoutil;

public interface DbConnectivity {

}
