package mindtree.playerauctionsystem.services.impl;

import mindtree.playerauctionsystem.dao.DaoServices;
import mindtree.playerauctionsystem.dao.impl.DaoServicesImpl;
import mindtree.playerauctionsystem.entity.Player;
import mindtree.playerauctionsystem.exception.DaoException;
import mindtree.playerauctionsystem.exception.ServiceException;
import mindtree.playerauctionsystem.services.PlayerAuctionServices;

public class PlayerAuctionServicesImpl implements PlayerAuctionServices {
        private DaoServices dao=new DaoServicesImpl();
	@Override
	public void addPlayer(Player player) throws ServiceException {
		// TODO Auto-generated method stub
		try {
			dao.addPlayer(player);
		}
		catch(DaoException e)
		{
			throw new ServiceException("",e);
		}
		
	}

}
