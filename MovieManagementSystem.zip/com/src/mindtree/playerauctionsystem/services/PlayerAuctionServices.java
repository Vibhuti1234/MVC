package mindtree.playerauctionsystem.services;

import mindtree.playerauctionsystem.entity.Player;
import mindtree.playerauctionsystem.exception.ServiceException;

public interface PlayerAuctionServices {
	public void  addPlayer(Player player) throws ServiceException;

}
