package mindtree.playerauctionsystem.entity;

public class Player {
private int playerNo;
private String playerName;
private String category;
private int highestScore;
private String bestFigure;

//public Player(int playerNo, String playerName, String category, int highestScore, String bestFigure) {
	//super();
	//this.playerNo = playerNo;
	//this.playerName = playerName;
	//this.category = category;
	//this.highestScore = highestScore;
	//this.bestFigure = bestFigure;
//}
public int getPlayerNo() {
	return playerNo;
}
public void setPlayerNo(int playerNo) {
	this.playerNo = playerNo;
}
public String getPlayerName() {
	return playerName;
}
public void setPlayerName(String playerName) {
	this.playerName = playerName;
}
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public int getHighestScore() {
	return highestScore;
}
public void setHighestScore(int highestScore) {
	this.highestScore = highestScore;
}
public String getBestFigure() {
	return bestFigure;
}
public void setBestFigure(String bestFigure) {
	this.bestFigure = bestFigure;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((playerName == null) ? 0 : playerName.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Player other = (Player) obj;
	if (playerName == null) {
		if (other.playerName != null)
			return false;
	} else if (!playerName.equals(other.playerName))
		return false;
	return true;
}
@Override
public String toString() {
	return "Player [playerNo=" + playerNo + ", playerName=" + playerName + ", category=" + category + ", highestScore="
			+ highestScore + ", bestFigure=" + bestFigure + "]";
}

}
