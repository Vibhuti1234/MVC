package mindtree.playerauctionsystem.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import mindtree.playerauctionsystem.dao.DaoServices;
import mindtree.playerauctionsystem.daoutil.impl.DbConnectivityImpl;
import mindtree.playerauctionsystem.entity.Player;
import mindtree.playerauctionsystem.exception.DaoException;
import mindtree.playerauctionsystem.exception.UtilityException;

public class DaoServicesImpl implements DaoServices{

	@Override
	public void addPlayer( Player player) throws DaoException {
		// TODO Auto-generated method stub
		Connection connection;
		try {
			connection=DbConnectivityImpl.getConnection();
			String query="insert into Player values (?,?,?,?,?)";
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			preparedStatement.setInt(1, player.getPlayerNo());
			preparedStatement.setString(2, player.getPlayerName());
			preparedStatement.setString(3,player.getCategory());
			preparedStatement.setInt(4,player.getHighestScore());
			preparedStatement.setString(5, player.getBestFigure());
			preparedStatement.executeUpdate();
			
		}
		catch(UtilityException e) {
			throw new DaoException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoException("Something wrong in sql Queries",e);
		}
		try {
			connection.close();
		}
		catch(SQLException e)
		{
			throw new DaoException("",e);
		}
		
	}

}
