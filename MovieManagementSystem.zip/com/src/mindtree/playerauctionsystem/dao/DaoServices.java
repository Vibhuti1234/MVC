package mindtree.playerauctionsystem.dao;

import mindtree.playerauctionsystem.entity.Player;
import mindtree.playerauctionsystem.exception.DaoException;

public interface DaoServices {
	public void addPlayer(Player player) throws DaoException;
	

}
