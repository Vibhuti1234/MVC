package mindtree.playerauctionsystem.client;

import java.util.Scanner;

import mindtree.playerauctionsystem.entity.Player;
import mindtree.playerauctionsystem.exception.InvalidCategoryException;
import mindtree.playerauctionsystem.exception.NotABatsmanException;
import mindtree.playerauctionsystem.exception.NotABowlerException;
import mindtree.playerauctionsystem.exception.ServiceException;
import mindtree.playerauctionsystem.services.PlayerAuctionServices;
import mindtree.playerauctionsystem.services.impl.PlayerAuctionServicesImpl;

public class PlayerAuctionApp {
	private static Scanner t=new Scanner(System.in);
	private static PlayerAuctionServices player=new PlayerAuctionServicesImpl();
	private static int s=0;
	public static void main(String args[])
	{
		do {System.out.println("\n1.to add Players.\n2.to display all Players\n3.To Exit\n Please Enter Your Choice:");
		      int ch=t.nextInt();
		      switch(ch) {
			case 1:
					try {
						addPlayer();
				} catch (InvalidCategoryException | NotABatsmanException | NotABowlerException | ServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			      break;
			     
			
		      }	
		}while(s!=1);
	}
	private static void addPlayer() throws ServiceException, InvalidCategoryException, NotABatsmanException, NotABowlerException {
		Player p=new Player();
		while(true) {
		System.out.println("Give Player Id:");
		int playerId=t.nextInt();
		p.setPlayerNo(playerId);
		t.nextLine();
		System.out.println("Enter Player Name");
		String playerName=t.nextLine();
		p.setPlayerName(playerName);
		System.out.println("Enter Category");
		 String category=t.nextLine();
		 if(category.equals("Batsmen")||category.equals("Bowler")||category.equals("AllRounder"))
		 {
			 p.setCategory(category);
			 if(category.equals("Batsmen"))
			 {
				 int highestScore=t.nextInt();
				 t.nextLine();
				 if(highestScore>=50 && highestScore<=200)
				 {
					 p.setHighestScore(highestScore);
				 }
				 else{ 
					 throw new NotABatsmanException("A Batsman Score Should not Be That Much Low:");
					 }
				 }
		 
		 else {
			 int highScore=t.nextInt();
			 t.nextLine();
			 p.setHighestScore(highScore);
		 }
			 System.out.println("Enter The Best Figure:");
		 if(category.equals("Bowler"))
		 {
			String bestFigure=t.nextLine();
			if(!bestFigure.equals(null))
			{
				p.setBestFigure(bestFigure);
			}
			else {
				throw new NotABowlerException("He Is Not A Bowler:");
			}
			
		 }
		 else {
			 String bestFigure=t.nextLine();
		 }
		 }
		 else {
			 throw new InvalidCategoryException("This Category Is Not Allowed:");
			 
			 
		 }
		
		 // p=new Player(playerId,playerName,category,highestScore,bestFigure);
		 player.addPlayer(p);
		 System.out.println("Do You Want to add More Players Y/N");
		 char c=t.next().charAt(0);
		 if(c=='N'||c=='n')
		 {
			 break;
		 }
		 }
		
		
	}

}
