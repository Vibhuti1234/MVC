package movie_entity;

public class Movie {
          private int movieId;
          private String movieName;
          private double Budget;
		public int getMovieId() {
			return movieId;
		}
		public void setMovieId(int movieId) {
			this.movieId = movieId;
		}
		public String getMovieName() {
			return movieName;
		}
		public void setMovieName(String movieName) {
			this.movieName = movieName;
		}
		public double getBudget() {
			return Budget;
		}
		public void setBudget(double budget) {
			Budget = budget;
		}
          
          
}
