package daoutil;
import java.sql.*;

import movie.exception.handling.DatabaseConnectivityException;

public class ConnectionUtil {
	private static final String URL="jdbc:mysql://localhost:3306/vibhuti?useSSL=false ";
	private static final String USERNAME="root";
	private static final String PASSWORD="Welcome123";
	//Class.forName("com.mysql.jdbc.Driver");

	private ConnectionUtil() {

	}
	private static Connection connection = null;

	public static Connection getConnection() throws DatabaseConnectivityException, ClassNotFoundException {
		if (ConnectionUtil.connection == null) {
			try {	Class.forName("com.mysql.jdbc.Driver");

				ConnectionUtil.connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);

			} catch (SQLException e) {
				throw new DatabaseConnectivityException("Unable to connect to database", e);
			}
		}
		return ConnectionUtil.connection;
	}


}
