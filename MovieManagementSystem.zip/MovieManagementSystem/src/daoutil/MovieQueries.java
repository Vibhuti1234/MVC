package daoutil;

public class MovieQueries {
	private MovieQueries() {
	}

	public static final String Movie_Name_By_Actor = "select movieName from movie m inner join actormoviecombine a on m.movieId=a.MID where AID=?";
	public static final String Actor_Name_By_Movie = "select actorName from actor a inner join actormoviecombine m on a.actorId=m.AID where MID=?";
}
