package movieclient;

import java.util.HashSet;
import java.util.Scanner;

import movie.exception.handling.ServiceException;
import movieservices.MovieManagementSystem;
import movieservices.MovieManagementSystemImpl;

public class MovieApp {
static int s=0;
static Scanner t=new Scanner(System.in);
public static void main(String args[]) throws ServiceException
{
	MovieManagementSystem service=new MovieManagementSystemImpl();
	GetMovieByActorId(service);
		
	
}
private static void GetMovieByActorId(MovieManagementSystem service) throws ServiceException {
	HashSet<String> h=new HashSet<String>();
			h=service.getMovieByActorId(1);
	for (String string : h) {
		System.out.println(string);
	}
	
}
}
