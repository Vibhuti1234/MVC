package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

import daoutil.ConnectionUtil;
import daoutil.ErrorMessageConstants;
import daoutil.MovieQueries;
import movie.exception.handling.DaoException;
import movie.exception.handling.DatabaseConnectivityException;
import movie_entity.Actor;
import movie_entity.Movie;

public class MovieDaoImpl implements MovieDao {

	@Override
	public HashSet<String> getMovieByActor(int actorId) throws DaoException, ClassNotFoundException {
		HashSet<String> s = new HashSet<String>();
		Connection connection;
		try {
			
			try {
				connection = ConnectionUtil.getConnection();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			try (PreparedStatement statement = connection.prepareStatement(MovieQueries.Movie_Name_By_Actor)) {
				statement.setLong(1, actorId);
				try (ResultSet rs = statement.executeQuery()) {
					while (rs.next()) {
						//System.out.println(rs.getString(1));
						s.add(rs.getString(1));

					}
				}
			}
		} catch (SQLException e) {
			throw new DaoException(ErrorMessageConstants.QUERY_ERROR, e);
		} catch (DatabaseConnectivityException e1) {
			throw new DaoException(ErrorMessageConstants.CONNECTION_UNAVAILABLE, e1);
		}
		return s;
	}

	@Override
	public Set<String> getActorByMovie(int movieId) {
		// TODO Auto-generated method stub
		return null;
	}

}
