package dao;

import java.util.HashSet;
import java.util.Set;

import movie.exception.handling.DaoException;
import movie_entity.Actor;
import movie_entity.Movie;

public interface MovieDao {
public HashSet<String> getMovieByActor(int actorId) throws DaoException, ClassNotFoundException;
public Set<String> getActorByMovie(int movieId);

}
