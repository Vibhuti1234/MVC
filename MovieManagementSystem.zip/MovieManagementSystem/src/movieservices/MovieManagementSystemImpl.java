package movieservices;

import java.util.HashSet;
import java.util.Set;

import dao.MovieDao;
import dao.MovieDaoImpl;
import movie.exception.handling.DaoException;
import movie.exception.handling.ServiceException;

public class MovieManagementSystemImpl implements MovieManagementSystem{
      MovieDao md=new MovieDaoImpl();
      
	@Override
	public HashSet<String> getMovieByActorId( int actorId) throws ServiceException, ClassNotFoundException {
		try {  
		return md.getMovieByActor(actorId);
		}
		catch(DaoException e) {
			throw new ServiceException(e);
		}
		
	}

	@Override
	public HashSet<String> getActorByMovieId( int movieId) {
		// TODO Auto-generated method stub
		return null;
	}
}
