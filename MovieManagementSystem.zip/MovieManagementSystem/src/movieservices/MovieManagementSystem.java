package movieservices;

import java.util.HashSet;

import movie.exception.handling.ServiceException;

public interface MovieManagementSystem {
	public HashSet<String>  getMovieByActorId(int actorId) throws ServiceException, ClassNotFoundException;
	public HashSet<String>  getActorByMovieId(int movieId);
	

}
