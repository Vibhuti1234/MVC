package service;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import exceptionhandling.DishNotAddedException;
import exceptionhandling.DuplicateDishId;
import exceptionhandling.DuplicateDishName;
import exceptionhandling.EmptyMenu;
import exceptionhandling.NoItemFoundOfThisId;
import exceptionhandling.NoItemFoundWithThisId;
import restrauntmanagemententity.Dishes;

public class RestrauntManagementServiceImpl implements RestarauntManagementService {
	private Set<Dishes> dishes = new HashSet<Dishes>();
	private Map<Dishes,Integer> cart=new HashMap<Dishes,Integer>();
	
	public Dishes addDish(Dishes dish) throws DuplicateDishId  {
		
		if(dishes.add(dish))
		{
			return dish;
		}
		else {
			throw new DuplicateDishId("Dish Id Already Present:");
		}
		
		
	}


	public void display() throws EmptyMenu{
		if(dishes.size()==0)
		{
			throw new EmptyMenu("No Dishes Added To Menu");
		}
		else {
			for(Dishes d:dishes)
			{
				System.out.println(d.getDishId()+" "+d.getDishName()+" "+d.getDishPrice());
			}
		}
		
		
	}

	@Override
	public void addToCart(int dishId) throws NoItemFoundWithThisId {
		int f=0;
		for(Dishes d1:dishes)
		{
			if(d1.getDishId()==dishId)
			{
				f=1;
				Integer i=cart.get(d1);
				if(i==null)
				{
					cart.put(d1, 1);
				}
				else {
					cart.put(d1, i+1);
				}
			}
		}
		if(f==0)
		{
			throw new NoItemFoundWithThisId("Item Not Found");
		}
		displayCart();
		
	}

	@Override
	public void displayCart() {
		// TODO Auto-generated method stub
		double total=0;
		for(Map.Entry<Dishes, Integer> map:cart.entrySet())
		{System.out.println(map.getKey().getDishId()+","+map.getKey().getDishName()+","+map.getValue());
			total+=((map.getKey().getDishPrice())*map.getValue());
		}
		System.out.println("--------------------------");
		System.out.println("Total"+total);
		
	}

	@Override
	public void changeCartQuantity(int dishId, int quantity) throws NoItemFoundOfThisId {
		// TODO Auto-generated method stub
		int f=0;
		for(Map.Entry<Dishes, Integer> map:cart.entrySet())
		{
			if(map.getKey().getDishId()==dishId)
			{
				f=1;
				cart.replace(map.getKey(), quantity);
			}
		}
		if(f==0)
		{
			throw new NoItemFoundOfThisId("No item found of this Id in cart:");
		}
		displayCart();
		
	}

	@Override
	public void removeItemFromCart(int dishid) throws NoItemFoundWithThisId {
		int f=0;
		for(Map.Entry<Dishes, Integer> map:cart.entrySet())
		{
			if(map.getKey().getDishId()==dishid)
			{
				f=1;
				cart.remove(map.getKey());
				break;
			}
			
		}
		if(f==0)
		{
			throw new NoItemFoundWithThisId("No item is here of This Id");
		}
		
	   displayCart();
		
	}

	@Override
	public void checkForDuplicateName(String dishname) throws DuplicateDishName {
		for(Dishes di:dishes)
		{
			if(di.getDishName().equals(dishname))
			{
				throw new DuplicateDishName("DishName Cannot be Same:");
			}
		}
	
		
	}
	

}
