package service;

import exceptionhandling.DishNotAddedException;
import exceptionhandling.DuplicateDishId;
import exceptionhandling.DuplicateDishName;
import exceptionhandling.EmptyMenu;
import exceptionhandling.NoItemFoundOfThisId;
import exceptionhandling.NoItemFoundWithThisId;
import restrauntmanagemententity.Dishes;

public interface RestarauntManagementService {
	public Dishes addDish(Dishes dish) throws DishNotAddedException, DuplicateDishId;
	public void display() throws EmptyMenu;
	public void addToCart(int dishId) throws NoItemFoundWithThisId;
	public void displayCart();
	public void changeCartQuantity(int dishId,int quantity) throws NoItemFoundOfThisId;
	public void removeItemFromCart(int dishid) throws NoItemFoundWithThisId;
	public void checkForDuplicateName(String dishname) throws DuplicateDishName;

}
