package restrauntmanagementclient;

import java.util.Scanner;

import exceptionhandling.DishNotAddedException;
import exceptionhandling.DuplicateDishId;
import exceptionhandling.DuplicateDishName;
import exceptionhandling.EmptyMenu;
import exceptionhandling.NoItemFoundOfThisId;
import exceptionhandling.NoItemFoundWithThisId;
import restrauntmanagemententity.Dishes;
import service.RestarauntManagementService;
import service.RestrauntManagementServiceImpl;

public class RestrauntApp {
	private static int s = 0;
	private static Scanner t = new Scanner(System.in);
	private static RestarauntManagementService service = new RestrauntManagementServiceImpl();


	public static void main(String args[]) throws DishNotAddedException, NoItemFoundWithThisId  {
		Dishes d = new Dishes();

		int choice;
		do {
			System.out.println(
					"\n1.Add Dishes\n2.Get All Dishes\n3.Add Dish To Cart\n4.Change Dish Quantity In Cart \n5.Delete From Cart\n6.To Exit");
			choice = t.nextInt();

			switch (choice) {
			case 1:addDish(service);
				break;
			case 2:display(service);
				break;
			case 3:addToCart(service);

				break;
			case 4:changeCartQuantity(service);

				break;
			case 5:removeItemFromCart(service);
				break;
			case 6:
				s = 1;
				break;
			default:
				System.out.println("Invalid Choice");
				break;
			}

		} while (s != 1);

	}

	private static void removeItemFromCart(RestarauntManagementService service2) throws NoItemFoundWithThisId {
		// TODO Auto-generated method stub
		service2.displayCart();
		System.out.println("Enter the DishId for Deletion:");
		int dishId=t.nextInt();
		service2.removeItemFromCart(dishId);
		
		
	}

	private static void changeCartQuantity(RestarauntManagementService service2) {
		service2.displayCart();
		System.out.println("Enter The DishId to Change Quantity:");
		int dishId=t.nextInt();
		System.out.println("Enter The New Quantity:");
		int newQuantity=t.nextInt();
		try {
			service2.changeCartQuantity(dishId, newQuantity);
		}
		catch(NoItemFoundOfThisId e)
		{
			e.printStackTrace();
		}	
	}

	private static void addToCart(RestarauntManagementService service2) {
		System.out.println("Enter The Dish Id You Want to Add");
		int dishId=t.nextInt();
		try {
			service2.addToCart(dishId);
		}
		catch(NoItemFoundWithThisId e)
		{
			e.printStackTrace();
			return;
		}
		
	}

	private static void display(RestarauntManagementService service2) {
		try {
			service2.display();
		}
		catch(EmptyMenu e)
		{
			e.printStackTrace();
			return;
		}
		
	}

	private static void addDish(RestarauntManagementService service2) throws DishNotAddedException {
		int dishId ;
		String dishName;
		double dishCost;
		Dishes dish=new Dishes();
		System.out.println("Enter The Dish Id");
		dishId=t.nextInt();
		dish.setDishId(dishId);
		t.nextLine();
		System.out.println("Give The name Of Dish Name:");
		dishName=t.nextLine();
		try {
			service2.checkForDuplicateName(dishName);
		}
		catch(DuplicateDishName e)
		{
			e.printStackTrace();
			return;
		}
		dish.setDishName(dishName);
		System.out.println("Enter The Dish Price:");
		dishCost=t.nextDouble();
		dish.setDishPrice(dishCost);
		try {
			Dishes dishentered=service2.addDish(dish);
			System.out.println("Dish Entered Successfully"+dishentered.getDishName());
		}
		catch(DuplicateDishId e)
		{
			e.printStackTrace();
			return;
		}
		
		
	

	}

}
