package restrauntmanagemententity;

public class Dishes {
@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + dishId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dishes other = (Dishes) obj;
		if (dishId != other.dishId)
			return false;
		return true;
	}
private int dishId;
private String dishName;
private double dishPrice;

public int getDishId() {
	return dishId;
}
public void setDishId(int dishId) {
	this.dishId = dishId;
}
public String getDishName() {
	return dishName;
}
public void setDishName(String dishName) {
	this.dishName = dishName;
}
public double getDishPrice() {
	return dishPrice;
}
public void setDishPrice(double dishPrice) {
	this.dishPrice = dishPrice;
}
@Override
public String toString() {
	return "Dishes [dishId=" + dishId + ", dishName=" + dishName + ", dishPrice=" + dishPrice + "]";
}

}
