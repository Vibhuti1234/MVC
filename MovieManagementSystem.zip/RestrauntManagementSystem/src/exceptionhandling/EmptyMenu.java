package exceptionhandling;

public class EmptyMenu extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EmptyMenu() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmptyMenu(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public EmptyMenu(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public EmptyMenu(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EmptyMenu(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

}
