package entity;

public class Dishes {

	private String dishName;
	
	private double dishPrice;

	public Dishes(String dishName, double dishPrice) {
		super();
		this.dishName = dishName;
		this.dishPrice = dishPrice;
	}

	public String getDishName() {
		return dishName;
	}

	public double getDishPrice() {
		return dishPrice;
	}

	

	@Override
	public String toString() {
		return "Dishes [dishName=" + dishName + ", dishPrice=" + dishPrice + "]";
	}


	
	
	

}
