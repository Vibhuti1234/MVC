package services;

import ExceptionHandling.DuplicateDishNameException;
import entity.Dishes;

public interface DishManagement {
	public void addDishes(Dishes d) throws  DuplicateDishNameException;
	public void getAllDishes();
	public void addToCart(String s,int quantity);
	public void changeDishQuantity(String dishName,int newQuantity);
	public void deleteInCart(String di);
	

}
