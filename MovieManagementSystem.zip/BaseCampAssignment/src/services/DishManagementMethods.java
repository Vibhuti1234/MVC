  package services;

import java.util.HashMap;

import java.util.HashSet;
import java.util.Set;

import ExceptionHandling.DuplicateDishNameException;

import entity.Dishes;

public class DishManagementMethods implements DishManagement {

	 Set<Dishes> k = new HashSet<Dishes>();
	public void addDishes(Dishes d) throws DuplicateDishNameException
	{ 
	   
		 
		 
	   }

	@Override
	public void getAllDishes() {
		// TODO Auto-generated method stub
		System.out.println("Your Dishes Are:");
		for (Dishes m : k) {
			System.out.println( m.getDishName() + " " + m.getDishPrice());
		}
	}

	static HashMap<String, Integer> hm = new HashMap<String, Integer>();

	public void addToCart(String s, int quantity) {
		int flag = 0;
		for (Dishes x : k) {
			if (x.getDishName().equals(s)) {
				hm.put(s, quantity);
				System.out.println("Dish Added Successfully:");
				flag = 1;
				break;
			}
		}
		if (flag == 0) {
			System.out.println("Dish Is Not Available:");
		}

	}

	@Override
	public void changeDishQuantity(String dishName, int newQuantity) {
		int f = 0;
		for (HashMap.Entry<String, Integer> entry : hm.entrySet()) {
			if (entry.getKey().equals(dishName)) {
				entry.setValue(newQuantity);
				System.out.println("Quantity Updated:");
				f = 1;
				break;
			}
		}
		if (f == 0) {
			System.out.println("Dish Not Found:");
		}

	}

	@Override
	public void deleteInCart(String di) {
		int f = 0;
		for (HashMap.Entry<String, Integer> ent : hm.entrySet()) {
			if (ent.getKey().equals(di)) {
				hm.remove(ent.getKey());
				f = 1;
				System.out.println("Element Deleted:");
				break;

			}
			else {
				System.out.println("There is No Such Element:");
			}
		}
		for (HashMap.Entry<String, Integer> en : hm.entrySet()) {
			System.out.println(en.getKey() + " " + en.getValue());

		}

		if (f == 0) {
			System.out.println("Dish Not Found:");

		}

	}
}