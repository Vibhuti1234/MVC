package client;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

import ExceptionHandling.DuplicateDishNameException;
import entity.Dishes;
import services.DishManagementMethods;

public class RestrauntManagementSystem {
	static int s=0;
	//static HashSet<Dishes> h=new HashSet<Dishes>();
    //static HashMap<String,Integer> hm;
	
	public static void main(String args[]) throws DuplicateDishNameException
	{
		Scanner t=new Scanner(System.in);
		do {System.out.println("Press 1 To Add a New Dish in Cart:");
		System.out.println("Press 2 to Get All Dishes:");
		System.out.println("Press 3 To Add a Dish To Cart:");
		System.out.println("Press 4 to Change Dish Quantity in Cart:");
		System.out.println("Press 5 to Delete  a Dish From Cart:");
		System.out.println("Press 6 to Exit:");
		System.out.println("Please enter your choice:");
		int ch=t.nextInt();
		t.nextLine();
		switch(ch)
		{
		case 1:
		      System.out.println("Give The name of Dish to be Added:");
		      String dishName=t.nextLine();
		      System.out.println("Enter The Price of Dish:");
		      double dishPrice=t.nextDouble();
		      Dishes d=new Dishes(dishName,dishPrice);
		      DishManagementMethods ob=new DishManagementMethods();
		      ob.addDishes(d);
		 
			break;
		case 2:   DishManagementMethods ob1=new DishManagementMethods();
		          ob1.getAllDishes();
			break;
		case 3:System.out.println("Give The Name of Dish to be Added:");
	          String  dishname=t.nextLine();
	          System.out.println("Quantity To Add:");
	          int quant=t.nextInt();
	          DishManagementMethods ob2=new DishManagementMethods();
	          ob2.addToCart(dishname, quant);
	          break;
		case 4:DishManagementMethods ob3=new DishManagementMethods();
		      System.out.println("Enter The name of Dish To change its Quantity:");
		      String Dish=t.nextLine();
		      System.out.println("Enter The New Quantity:");
		      int newquant=t.nextInt();
		      ob3.changeDishQuantity(Dish, newquant);
		      break;
		case 5:System.out.println("Enter the Dish Name To Remove :");
		        String dishName2=t.nextLine();
		        DishManagementMethods ob4=new DishManagementMethods();
		        ob4.deleteInCart(dishName2);
		        
			 break;
		case 6:s=1;
			 break;
		default:System.out.println("Invalid Choice Try Again:");
			break;
		}
			
		}while(s!=1);
		
		
		
	}
}
