package service;

import java.util.List;
import java.util.Set;

import dao.DaoServices;
import dao.DaoServicesImpl;
import entity.Actor;
import entity.Movie;
import exception.DaoException;
import exception.ServiceException;

public class MovieServiceImpl implements MovieService {
     private DaoServices dao=new DaoServicesImpl();
	@Override
	public List<Actor> getActors(int movieId) throws ServiceException {
		try {
			return dao.getActors(movieId);
		}
		catch(DaoException e){
			throw new ServiceException("",e);
			
		}
		
	}

	@Override
	public boolean checkActor(String actorName) throws ServiceException {
	  try {
		return dao.checkActor(actorName);
	  }
	  catch(DaoException e) {
		  throw new ServiceException("",e);
	  }
	}

	@Override
	public void addActor(String actorName) throws ServiceException {
		// TODO Auto-generated method stub
		 try {
				 dao.addActor(actorName);;
			  }
			  catch(DaoException e) {
				  throw new ServiceException("",e);
			  }

		
	}

	@Override
	public List<Actor> getAllActors() throws ServiceException {
		 try {
				return dao.getAllActors();
			  }
			  catch(DaoException e) {
				  throw new ServiceException("",e);
			  }

	}

	@Override
	public List<Movie> getMovies(int actorId) throws ServiceException {
		// TODO Auto-generated method stub
		 try {
				return dao.getMovies(actorId);
			  }
			  catch(DaoException e) {
				  throw new ServiceException("",e);
			  }

	}

	@Override
	public List<Movie> getMovieBudget(double budget) throws ServiceException {
		// TODO Auto-generated method stub
		 try {
				return dao.getMovieBudget(budget);
			  }
			  catch(DaoException e) {
				  throw new ServiceException("",e);
			  }

	}

	@Override
	public boolean checkMovie(String movieName) throws ServiceException {
		// TODO Auto-generated method stub
		 try {
				return dao.checkMovie(movieName);
			  }
			  catch(DaoException e) {
				  throw new ServiceException("",e);
			  }

	}

	@Override
	public void addMovie(Movie movie) throws ServiceException {
		 try {
				 dao.addMovie(movie);
			  }
			  catch(DaoException e) {
				  throw new ServiceException("",e);
			  }

		
	}

	@Override
	public boolean checkMovie(int movieId) throws ServiceException {
		 try {
				return dao.checkMovie(movieId);
			  }
			  catch(DaoException e) {
				  throw new ServiceException("",e);
			  }

		
	}

	@Override
	public void registerActor(Set<Integer> actorIds, int movieId) throws ServiceException {
		 try {
			dao.registerActor(actorIds, movieId);;
			  }
			  catch(DaoException e) {
				  throw new ServiceException("",e);
			  }

		
	}

}
