package service;

import java.util.List;
import java.util.Set;

import entity.Actor;
import entity.Movie;
import exception.ServiceException;

public interface MovieService {
	public List<Actor> getActors(int movieId) throws ServiceException;
	public boolean checkActor(String actorName) throws ServiceException;
	public void addActor(String actorName) throws ServiceException;
	public List<Actor> getAllActors() throws ServiceException;
	public List<Movie> getMovies(int actorId) throws ServiceException;
	public List<Movie> getMovieBudget(double budget) throws ServiceException;
	public boolean checkMovie(String movieName) throws ServiceException;
	public void addMovie(Movie movie) throws ServiceException;
	public boolean checkMovie(int movieId) throws ServiceException;
	public void registerActor(Set<Integer> actorIds,int movieId) throws ServiceException;

}
