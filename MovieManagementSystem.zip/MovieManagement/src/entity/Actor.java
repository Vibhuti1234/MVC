package entity;

public class Actor {
private int actorId;
private String actorName;
public Actor(int actorId, String actorName) {
	super();
	this.actorId = actorId;
	this.actorName = actorName;
}
public int getActorId() {
	return actorId;
}
public void setActorId(int actorId) {
	this.actorId = actorId;
}
public String getActorName() {
	return actorName;
}
public void setActorName(String actorName) {
	this.actorName = actorName;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((actorName == null) ? 0 : actorName.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Actor other = (Actor) obj;
	if (actorName == null) {
		if (other.actorName != null)
			return false;
	} else if (!actorName.equals(other.actorName))
		return false;
	return true;
}
@Override
public String toString() {
	return "Actor [actorId=" + actorId + ", actorName=" + actorName + "]";
};


}
