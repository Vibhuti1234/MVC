package utility;

public interface DbConnectivity {

}
