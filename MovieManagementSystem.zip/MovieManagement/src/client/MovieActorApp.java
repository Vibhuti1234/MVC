package client;

import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import entity.Actor;
import entity.Movie;
import exception.ActorAlreadyPresentException;
import exception.MovieAlreadyExists;
import exception.ServiceException;
import service.MovieService;
import service.MovieServiceImpl;

public class MovieActorApp {
	private static int s=0;
	private static  Scanner t=new Scanner(System.in);
	private static MovieService m=new MovieServiceImpl();
	public static void main(String args[])
	{
		do {
			System.out.println("1.To Add Actors\n2.To Add Movies\n3.To register Actors to Movies\n4.to print Movies of a Actor\n5.to print actors"
					+ "of a movie\n6.print movies whose budget  greater than x\n7.to Exit\nPlease Enter Your Choice:");
            int ch=t.nextInt();
            t.nextLine();
           switch (ch) {
		case 1:addActor();
			break;
         case 2:addMovie();
			break;
         case 3:registerActor();
 			break;
         case 4:printMovieByActor();
 			break;
         case 5:printActorByMovie();
 			break;
         case 6:printMoviesBudget();
 			break;
         case 7:
 			   
 			break;

		default:System.out.println("Invalid Choice try Again");
			break;
		}
			
			
		}while(s!=1);
	}
	private static void addActor() {
		// TODO Auto-generated method stub
		String actorName="";
		while(true)
		{
			System.out.println("Enter Actor Name:");
			actorName=t.nextLine();
			try {
				if(m.checkActor(actorName)) {
					throw new ActorAlreadyPresentException("This actor is Already present");
				}
				m.addActor(actorName);
				System.out.println("Do You Want To Add Another Actor Y/N");
				char c=t.next().charAt(0);
				if(c=='n'||c=='N')
				{
					break;
				}
					
			}catch(ServiceException | ActorAlreadyPresentException e)
			{
				e.printStackTrace();
			}
		}
		
	}
	private static void addMovie() {
		// TODO Auto-generated method stub
		String movieName="";
		while(true) {
			System.out.println("Enter Movie Name:");
			movieName=t.nextLine();
			System.out.println("Add Budget:");
			double budget=t.nextDouble();
			try {
				if(m.checkMovie(movieName))
				{
					throw new MovieAlreadyExists("Movie is Already There:");
				}
				Movie movie=new Movie(0,movieName,budget);
				m.addMovie(movie);
				System.out.println("do u want to add more movies Y/N");
				char c=t.next().charAt(0);
				if(c=='n'|| c=='N')
				{
					break;
				}
			}catch(ServiceException|MovieAlreadyExists e)
			{
				e.printStackTrace();
			}
		}
		
	}
	private static void registerActor() {
		List<Actor> actors;
		try {
			System.out.println("Enter Movie Id");
			int movieId=t.nextInt();
			if(!m.checkMovie(movieId))
			{
				throw new MovieAlreadyExists("Movie not Found:");
			}
			actors=m.getAllActors();
			for (Actor actor : actors) {
				System.out.println(actor);	
			}
			Set<Integer> actorIds=new HashSet<>();
			while(true)
			{
				System.out.println("Enter Actor Id");
				int actorId=t.nextInt();
				actorIds.add(actorId);
				System.out.println("Do you want to add another actors for The Same Movie: Y/N");
				char c=t.next().charAt(0);
				if(c=='n'||c=='N')
				{
					break;
				}
				
			}
			m.registerActor(actorIds, movieId);
		}
		catch(ServiceException|MovieAlreadyExists e)
		{
			e.printStackTrace();
		}
		
		
	}
	private static void printMovieByActor() {
		// TODO Auto-generated method stub
		System.out.println("Enter actor Id");
		int actorId=t.nextInt();
		List<Movie> movies;
		try {
			movies=m.getMovies(actorId);
			for (Movie movie : movies) {
				System.out.println(movie.getMovieId()+" "+movie.getMovieName()+" "+movie.getBudget());
				
			}
		}catch(ServiceException e)
		{
			e.printStackTrace();
		}

		
	}
	private static void printActorByMovie() {
		// TODO Auto-generated method stub
		System.out.println("Enter Movie Id");
		int movieId=t.nextInt();
		try {
			List<Actor> actors=m.getActors(movieId);
			for (Actor actor : actors) {
				System.out.println(actor);
				
			}
		}
		catch(ServiceException e) {
			e.printStackTrace();
		}
		
		
	}
	private static void printMoviesBudget() {
		// TODO Auto-generated method stub
		System.out.println("Enter The Budget X:");
		double budget=t.nextDouble();
		List<Movie> movies;
		try {movies=m.getMovieBudget(budget);
		    for (Movie movie : movies) {
		    	System.out.println(movie.getMovieId()+" "+movie.getMovieName()+" "+movie.getBudget());
				
			}
		}
		catch(ServiceException e)
		{
			e.printStackTrace();
		}
		
	}

}
