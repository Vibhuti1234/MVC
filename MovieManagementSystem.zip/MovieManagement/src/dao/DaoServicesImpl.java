package dao;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.sql.*;

import entity.Actor;
import entity.Movie;
import exception.DaoException;
import exception.UtilityException;
import utility.DbConnectivity;
import utility.DbConnectivityImpl;

public class DaoServicesImpl implements DaoServices {

	public List<Actor> getActors(int movieId) throws DaoException {
		List<Actor> actors;
		Connection connection;
		try {
			connection=DbConnectivityImpl.getConnection();
			String query="select actorId,actorName from actor a inner join actormoviecombine am on a.actorId=am.AID where am.MID=?";
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			preparedStatement.setInt(1, movieId);
			ResultSet rs=preparedStatement.executeQuery();
			actors =new ArrayList<>();
			while(rs.next())
			{
				Actor actor=new Actor(rs.getInt("actorId"),rs.getString("actorName"));
				actors.add(actor);
			}
			
		}
		catch(UtilityException e) {
			throw new DaoException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoException("Something wrong in sql Queries",e);
		}
		/*try {
			connection.close();
		}
		catch(SQLException e)
		{
			throw new DaoException("",e);
		}*/
		return actors;
	}


	public boolean checkActor(String actorName) throws DaoException {
		// TODO Auto-generated method stub
		Connection connection;
		try {
			connection=DbConnectivityImpl.getConnection();
			String query="select * from actor where actor.actorName=?";
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			preparedStatement.setString(1, actorName);
			ResultSet rs=preparedStatement.executeQuery();
			if(rs.next())
			{
				return true;
			}}
			catch(UtilityException e) {
				throw new DaoException("Something Wrong in Utility class",e);
			}
			catch(SQLException e) {
				throw new DaoException("Something wrong in sql Queries",e);
			}
			/*try {
				connection.close();
			}
			catch(SQLException e)
			{
				throw new DaoException("",e);
			}*/
		
		return false;
	}

	@Override
	public void addActor(String actorName) throws DaoException {
		// TODO Auto-generated method stub
		Connection connection;
		try {connection=DbConnectivityImpl.getConnection();
		      String query="insert into actor(actorName) values (?)";
		      PreparedStatement preparedStatement=connection.prepareStatement(query);
		      preparedStatement.setString(1,actorName);
		      preparedStatement.executeUpdate();	
		}
		catch(UtilityException e) {
			throw new DaoException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoException("Something wrong in sql Queries",e);
		}
		/*try {
			connection.close();
		}
		catch(SQLException e)
		{
			throw new DaoException("",e);
		}*/
		
	}



	@Override
	public List<Movie> getMovies(int actorId) throws DaoException {
		Connection connection;
		List<Movie> movies;
		try {
			connection=DbConnectivityImpl.getConnection();
			movies=new ArrayList<>();
			String query="select movieId,movieName,Budget from movie m inner join actormoviecombine a on m.movieId =a.MID where a.AID=?";
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			preparedStatement.setInt(1, actorId);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				Movie movie=new Movie(rs.getInt("movieId"),rs.getString("movieName"),rs.getDouble("Budget"));
				movies.add(movie);
			}
			
		}
		catch(UtilityException e) {
			throw new DaoException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoException("Something wrong in sql Queries",e);
		}
		/*try {
			connection.close();
		}
		catch(SQLException e)
		{
			throw new DaoException("",e);
		}*/
		return movies;
	}

	@Override
	public List<Movie> getMovieBudget(double budget) throws DaoException {
		// TODO Auto-generated method stub
		Connection connection;
		List<Movie> movies;
		try {
			connection=DbConnectivityImpl.getConnection();
			movies=new ArrayList<>();
			String query="select * from movie where Budget >=?";
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			preparedStatement.setDouble(1, budget);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				Movie movie=new Movie(rs.getInt("movieId"),rs.getString("movieName"),rs.getDouble("Budget"));
				movies.add(movie);
				
			}
		}
		catch(UtilityException e) {
			throw new DaoException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoException("Something wrong in sql Queries",e);
		}
		/*try {
			connection.close();
		}
		catch(SQLException e)
		{
			throw new DaoException("",e);
		}*/
		return movies;
	}

	@Override
	public boolean checkMovie(String movieName) throws DaoException {
		Connection connection;
		try {
			connection=DbConnectivityImpl.getConnection();
			String query="select * from movie where movie.movieName=?";
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			preparedStatement.setString(1, movieName);
			ResultSet rs=preparedStatement.executeQuery();
			if(rs.next())
			{
				return true;
			}
			
		}
		catch(UtilityException e) {
			throw new DaoException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoException("Something wrong in sql Queries",e);
		}
		/*try {
			connection.close();
		}
		catch(SQLException e)
		{
			throw new DaoException("",e);
		}*/
		return false;
	}

	@Override
	public void addMovie(Movie movie) throws DaoException {
		// TODO Auto-generated method stub
		Connection connection;
		try {
			connection=DbConnectivityImpl.getConnection();
			String query="insert into movie(movieName,Budget) values (?,?)";
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			preparedStatement.setString(1, movie.getMovieName());
			preparedStatement.setDouble(2, movie.getBudget());
			preparedStatement.executeUpdate();
		}
		catch(UtilityException e) {
			throw new DaoException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoException("Something wrong in sql Queries",e);
		}
		/*try {
			connection.close();
		}
		catch(SQLException e)
		{
			throw new DaoException("",e);
		}*/
		
	}

	@Override
	public boolean checkMovie(int movieId) throws DaoException {
	    Connection connection;
	    try {
	    	connection=DbConnectivityImpl.getConnection();
	    	 String query="select * from movie where movie.movieId=?";
	    	 PreparedStatement preparedStatement=connection.prepareStatement(query);
	    	 preparedStatement.setInt(1, movieId);
	    	 ResultSet rs=preparedStatement.executeQuery();
	    	 if(rs.next())
	    	 {
	    		 return true;
	    	 }	 
	    }
	    catch(UtilityException e) {
			throw new DaoException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoException("Something wrong in sql Queries",e);
		}
		//try {
			//connection.close();
		//}
		//catch(SQLException e)
		//{
			//throw new DaoException("",e);
		//}
		return false;
	}

	@Override
	public void registerActor(Set<Integer> actorIds, int movieId) throws DaoException {
		// TODO Auto-generated method stub
		Connection connection;
		try {
			connection=DbConnectivityImpl.getConnection();
			String query="insert into actormoviecombine values (?,?)";
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			for (Integer integer : actorIds) {
				preparedStatement.setInt(1, movieId);
				preparedStatement.setInt(2, integer);
				preparedStatement.executeUpdate();
				
			}
		}
		catch(UtilityException e) {
			throw new DaoException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoException("Something wrong in sql Queries",e);
		}
		/*try {
			connection.close();
		}
		catch(SQLException e)
		{
			throw new DaoException("",e);
		}*/
	}

	@Override
	public List<Actor> getAllActors() throws DaoException {
		List<Actor> actors=new ArrayList<>();
		Connection connection;
		try {
			connection=DbConnectivityImpl.getConnection();
			String query="select * from actor";
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				actors.add(new Actor(rs.getInt("actorId"),rs.getString("actorName")));
			}
		}
		catch(UtilityException e) {
			throw new DaoException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoException("Something wrong in sql Queries",e);
		}
		/*try {
			connection.close();
		}
		catch(SQLException e)
		{
			throw new DaoException("",e);
		}*/
		return actors;
	}

}
