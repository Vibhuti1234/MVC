package dao;

import java.util.List;
import java.util.Set;

import entity.Actor;
import entity.Movie;
import exception.DaoException;

public interface DaoServices {
	public List<Actor> getActors(int movieId) throws DaoException;
	public boolean checkActor(String actorName) throws DaoException;
	public void addActor(String actorName) throws DaoException;
	public List<Actor> getAllActors() throws DaoException;
	public List<Movie> getMovies(int actorId) throws DaoException;
	public List<Movie> getMovieBudget(double budget) throws DaoException;
	public boolean checkMovie(String movieName) throws DaoException;
	public void addMovie(Movie movie) throws DaoException;
	public boolean checkMovie(int movieId) throws DaoException;
	public void registerActor(Set<Integer> actorId,int movieId) throws DaoException;
	
 
}
