package TrainEntity;

public class Seat {
	private String seatName;

	public String getSeatName() {
		return seatName;
	}

	@Override
	public String toString() {
		return "Seat [seatName=" + seatName + "]";
	}

	public void setSeatName(String seatName) {
		this.seatName = seatName;
	}
	
	public Seat(String st)
	{
		this.seatName=st;
	}

}
