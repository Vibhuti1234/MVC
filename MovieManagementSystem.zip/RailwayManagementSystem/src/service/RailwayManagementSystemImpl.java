package Service;

import java.util.HashSet;
import java.util.Set;

import TrainEntity.Booking;
import TrainEntity.Seat;
import TrainEntity.Train;
import TrainExceptionHandling.DuplicateBookingIdException;
import TrainExceptionHandling.DuplicateSeatNameException;
import TrainExceptionHandling.DuplicateTrainId;
import TrainExceptionHandling.DuplicateTrainNameException;
import TrainExceptionHandling.EmptyTrainListException;

public class RailwayManagementSystemImpl implements RailwayManagementSystem {
     Set<Train> tr=new HashSet<Train>();
     Set<Seat> seat=new HashSet<Seat>();
     Set<Booking> book=new HashSet<Booking>();
	@Override
	public Train addTrain(Train train) throws DuplicateTrainId {
		if(tr.add(train))
		{
			return train;
		}
		else {
			throw new DuplicateTrainId("This Train Number Already Present:");
		}
		
	}

	@Override
	public Booking addBooking(Booking booking) throws DuplicateBookingIdException {
		// TODO Auto-generated method stub
		if(book.add(booking))
		{
			return booking;
		}
		else {
			throw new DuplicateBookingIdException("This Booking Id Is Already Present:");
		}
		
	}

	@Override
	public void deleteBooking(int bookingId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changeBooking(int bookingId, String newSeatName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getTrain() throws EmptyTrainListException {
		if(tr.size()==0)
		{
			throw new EmptyTrainListException("There is No Train Added;");
		}
		else {
			for(Train t:tr)
			{
				System.out.println(t.getTrainName()+" "+t.getTrainNumber()+" "+t.getTrainTime());
			}
		}
		
	}

	@Override
	public void getBooking() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void checkForDuplicateName(String trainName) throws DuplicateTrainNameException {
		// TODO Auto-generated method stub
		for(Train train:tr)
		{ if(train.getTrainName().equals(trainName))
		{
			throw new DuplicateTrainNameException("Train name Already There:");
		}
			
		}
		
	}

	@Override
	public void checkForDuplicateSeatName(String seatName) throws DuplicateSeatNameException {
		// TODO Auto-generated method stub
		for(Booking b:book)
		{
			for(int i=0;i<b.getSeat().length;i++)
			{
				if(b.getSeat()[i].getSeatName().equals(seatName))
				{
					throw new DuplicateSeatNameException("This Seat is Already Booked");
				}
			}
		}
		
	}

}
