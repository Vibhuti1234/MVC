package Service;

import TrainEntity.Booking;
import TrainEntity.Train;
import TrainExceptionHandling.DuplicateBookingIdException;
import TrainExceptionHandling.DuplicateSeatNameException;
import TrainExceptionHandling.DuplicateTrainId;
import TrainExceptionHandling.DuplicateTrainNameException;
import TrainExceptionHandling.EmptyTrainListException;

public interface RailwayManagementSystem {
	public Train addTrain(Train train) throws DuplicateTrainId;
	public Booking addBooking(Booking booking) throws DuplicateBookingIdException;
	public void deleteBooking(int bookingId);
	public void changeBooking(int bookingId,String newSeatName);
	public void getTrain() throws EmptyTrainListException;
	public void getBooking();
	public void checkForDuplicateName(String trainName) throws DuplicateTrainNameException;
	public void checkForDuplicateSeatName(String seatName) throws DuplicateSeatNameException;

}
