package TrainExceptionHandling;

public class DuplicateSeatNameException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DuplicateSeatNameException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DuplicateSeatNameException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public DuplicateSeatNameException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public DuplicateSeatNameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public DuplicateSeatNameException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	

}
