package TrainClient;

import java.util.Scanner;

import Service.RailwayManagementSystem;
import Service.RailwayManagementSystemImpl;
import TrainEntity.Booking;
import TrainEntity.Seat;
import TrainEntity.Train;
import TrainExceptionHandling.DuplicateBookingIdException;
import TrainExceptionHandling.DuplicateSeatNameException;
import TrainExceptionHandling.DuplicateTrainId;
import TrainExceptionHandling.DuplicateTrainNameException;
import TrainExceptionHandling.EmptyTrainListException;

public class TrainApp {
	static int s = 0;
	static Scanner t = new Scanner(System.in);

	public static void main(String args[]) {
		RailwayManagementSystem service = new RailwayManagementSystemImpl();
		do {
			System.out.println(
					"1.For Add Train\n2.For Add Booking\n3.delete Booking\n4.change Booking\n5.To get Trains\n6.get Booking");
			System.out.println("Please Enter Your Choice:");
			int choice = t.nextInt();
			switch (choice) {
			case 1:
				addTrain(service);
				break;
			case 2:
				addBooking(service);
				break;
			case 3:
				deleteBooking(service);
				break;
			case 4:
				changeBooking(service);
				break;
			case 5:
				getTrain(service);
				break;
			case 6:
				getBooking(service);
				break;

			}

		} while (s != 1);

	}

	private static void getBooking(RailwayManagementSystem service) {

	}

	private static void getTrain(RailwayManagementSystem service) {
		try {
			service.getTrain();
		} catch (EmptyTrainListException e) {
			e.printStackTrace();
			return;

		}

	}

	private static void changeBooking(RailwayManagementSystem service) {
		// TODO Auto-generated method stub

	}

	private static void deleteBooking(RailwayManagementSystem service) {
		// TODO Auto-generated method stub

	}

	private static void addBooking(RailwayManagementSystem service) {
		// TODO Auto-generated method stub
		int bookingId;
		Train tra = new Train();
		Booking b = new Booking();
		System.out.println("Enter The Booking Id:");
		bookingId = t.nextInt();
		b.setBookingId(bookingId);
		System.out.println("Enter The Number Of Seats:");
		int n = t.nextInt();
		t.nextLine();
		Seat[] ob = new Seat[n];
		for (int i = 0; i < n; i++) {
			System.out.println("Give Seat Name :" + (i + 1));
			String seatName = t.nextLine();
			try {
				service.checkForDuplicateSeatName(seatName);
			} catch (DuplicateSeatNameException e) {
				e.printStackTrace();
				return;
			}

			ob[i] = new Seat(seatName);

		}
		b.setSeat(ob);
		System.out.println("Enter The Train Details:");
		System.out.println("Enter The Train Id:");
		int trainId = t.nextInt();
		t.nextLine();
		tra.setTrainNumber(trainId);
		System.out.println("Enter The Train Name");
		String trainName = t.nextLine();
		tra.setTrainName(trainName);
		System.out.println("Enter The Train Time");
		String trainTime = t.nextLine();
		tra.setTrainTime(trainTime);
		b.setTrain(tra);
		try {
			Booking getBook = service.addBooking(b);
			System.out.println("Booking Confirm:" + b.getBookingId());
		} catch (DuplicateBookingIdException e) {
			e.printStackTrace();
			return;

		}
	}

	private static void addTrain(RailwayManagementSystem service) {
		int trainNumber;
		String trainName;
		String trainTime;
		Train tr = new Train();
		System.out.println("Enter Train Number");
		trainNumber = t.nextInt();
		t.nextLine();
		tr.setTrainNumber(trainNumber);
		System.out.println("Enter The Train Name");
		trainName = t.nextLine();
		try {
			service.checkForDuplicateName(trainName);
		} catch (DuplicateTrainNameException e) {
			e.printStackTrace();
			return;

		}
		tr.setTrainName(trainName);
		System.out.println("Enter the Train Time:");
		trainTime = t.nextLine();
		tr.setTrainTime(trainTime);
		try {
			Train trainEntered = service.addTrain(tr);
			System.out.println("Train Entered Successfully Jai Ho:" + trainEntered.getTrainName());
		} catch (DuplicateTrainId e) {
			e.printStackTrace();
			return;
		}

	}

}
