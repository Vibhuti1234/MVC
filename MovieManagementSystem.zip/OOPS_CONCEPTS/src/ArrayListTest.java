import java.util.ArrayList;

public class ArrayListTest {
	public static void main(String[] args)
	{
		ArrayList<Integer> ali=new ArrayList<Integer>(15);
		for(int i=1;i<=15;i++)
		{
			ali.add(i);
		}
		System.out.println(ali);
		ali.remove(5);
		

		System.out.println(ali);
		ali.remove(5);
		System.out.println(ali);

		for(int i=0;i<ali.size();i++)
		{
			System.out.print(ali.get(i)+" ");
		}
		System.out.println();
		for(Integer i:ali)
		{
			System.out.print(i+" ");
		}
		
		
	}

}
