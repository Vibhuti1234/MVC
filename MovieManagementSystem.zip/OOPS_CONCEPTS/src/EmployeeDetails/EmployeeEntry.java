package EmployeeDetails;

import java.util.HashSet;
import java.util.Scanner;

public class EmployeeEntry {
	
	public static void main(String args[])
	{
		Scanner t=new Scanner(System.in);
		HashSet<Employee> h=new HashSet<Employee>();
		
		System.out.println("Enter the No of Employee:");
		int n=t.nextInt();
		t.nextLine();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the details of Employee No."+(i+1));
			System.out.println("Enter Employee Id:");
			String eid=t.nextLine();
			System.out.println("Enter Employee Name:");
			String ename=t.nextLine();
			Employee e=new Employee(eid,ename);
			boolean check=IsAlreadyThere(h,e);
			if(check==true)
			{
				System.out.println("Employee Details Added Successfully with Mid"+eid);
			}
			else {
				System.out.println("Employee is already There:");
			}
			
		}
		
		
	}

	private static boolean IsAlreadyThere(HashSet<Employee> h, Employee e) {
	
		
		return h.add(e);
	}

}
