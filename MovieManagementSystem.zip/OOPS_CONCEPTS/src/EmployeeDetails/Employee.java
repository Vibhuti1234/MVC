package EmployeeDetails;

import java.util.Collection;

public class Employee {
	private String EmployeeId;
	private String EmployeeName;
	public Employee(String EmployeeId,String EmployeeName)
	{
		this.EmployeeId=EmployeeId;
		this.EmployeeName=EmployeeName;
	}
	public String getEmployeeId() {
		return EmployeeId;
	}
	public String getEmployeeName() {
		return EmployeeName;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((EmployeeId == null) ? 0 : EmployeeId.hashCode());
		//result = prime * result + ((EmployeeName == null) ? 0 : EmployeeName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (EmployeeId == null) {
			if (other.EmployeeId != null)
				return false;
		} else if (!EmployeeId.equals(other.EmployeeId))
			return false;
//		if (EmployeeName == null) {
//			if (other.EmployeeName != null)
//				return false;
//		} else if (!EmployeeName.equals(other.EmployeeName))
//			return false;
		return true;
	}
	

}
