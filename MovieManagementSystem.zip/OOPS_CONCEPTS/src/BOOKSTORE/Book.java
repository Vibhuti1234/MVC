package BOOKSTORE;

public class Book implements Comparable<Book> {
private String BookName;
private String Author;
private int Price;

public Book(String BookName,String Author,int Price)
{
	this.BookName=BookName;
	this.Author=Author;
	this.Price=Price;
}
public String getBookName() {
	return BookName;
}

public String getAuthor() {
	return Author;
}
public int getPrice() {
	return Price;
}
@Override
public int compareTo(Book m) {
	// TODO Auto-generated method stub
	return this.Price-m.Price;
}


}
