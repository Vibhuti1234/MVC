package BOOKSTORE;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class BookManagementSystem {
	public static void main(String args[])
	{
		System.out.println("Give the no of Books");
		Scanner t=new Scanner(System.in);
		int n=t.nextInt();
		t.nextLine();
		ArrayList<Book> a=new ArrayList<Book>();
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter The Details of"+(i+1)+"Book");
			System.out.println("Enter the name of Book:");
			String bname=t.nextLine();
			System.out.println("Enter the name of BookAuthor:");
			String bauthor=t.nextLine();
			System.out.println("Enter The Price of book:");
			int bprice=t.nextInt();
			t.nextLine();
			Book b=new Book(bname,bauthor,bprice);
			a.add(b);

		
			
		}
		Collections.sort(a, Collections.reverseOrder());
		for(Book s:a)
		{
			System.out.println(s.getBookName()+"    "+s.getAuthor()+"    "+s.getPrice());
		}
        t.close();
	}

}
