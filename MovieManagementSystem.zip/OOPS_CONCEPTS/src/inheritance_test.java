class bicycle{
	public int gear;
	public int speed;
	public bicycle(int gear,int speed)
	{
		this.gear=gear;
		this.speed=speed;
		
	}
	public void applybrake(int decrement)
	{
		speed-=decrement;
	}
	public void speedup(int increment)
	{
		speed+=increment;
	}
	public String toString()
	{
		return ("No of gears are"+gear+"\n"+"Speed of bicycle is"+speed);
	}
}

	class mountbike extends bicycle{
		public int seatheight;

		public mountbike(int gear, int speed,int seatheight) {
			super(gear, speed);
			// TODO Auto-generated constructor stub
			this.seatheight=seatheight;
			
		}
		public void setHeight(int newvalue)
		{
			seatheight=newvalue;
		}
		public String toString()
		{
			return(super.toString()+"\n saet height is"+seatheight);
		}
		
	}
public class inheritance_test {
	public static void main(String args[])
	
	{
		mountbike m=new mountbike(3,5,8);
		System.out.println(m.toString());
	}

}
