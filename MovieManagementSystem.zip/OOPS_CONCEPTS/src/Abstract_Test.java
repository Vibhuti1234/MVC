abstract class shape
{
	String color;
	abstract double area();
	public abstract String toString();
	public shape(String color)
	{
		System.out.println("abstract class can have paramaterized constructor:");
		this.color=color;
		
	}
	public String getColor()
	{
		return color;
	}
}
class circle extends shape{
       double radius;
	public circle(String color,double radius) {
		super(color);
		System.out.println("Class constructor called:");
		this.radius=radius;
		
	}
	public double  area()
	{return Math.PI*Math.pow(radius, 2);	
	}
	   public String toString() { 
	        return "Circle color is " + super.color +  
	                       " and area is : " + area();}
	
}
public class Abstract_Test {
	public static void main(String args[])
	{ shape s=new circle("Red",8.9);
	System.out.println(s.toString());
		
	}

}
