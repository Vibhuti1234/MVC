import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

class Employee implements Comparable<Employee> {
	private int  eid;
	private String ename;
	private int salary;

	
	public Employee(int eid, String ename, int salary) {
		this.eid=eid;
		this.ename=ename;
		this.salary=salary;}
	

	public int getEid() {
		return eid;
	}

	public String getEname() {
		return ename;
	}
	public int getSalary() {
		return salary;
	}
	public int compareTo(Employee m) 
    { 
        return this.salary - m.salary; 
    } 
  
	

}

public class Employee_test {
 static int s=0;
	public static void main(String args[])
	{  
	    Scanner t=new Scanner(System.in);
		Employee e1=new Employee(1,"A",2000);
		Employee e2=new Employee(2,"B",2100);
		Employee e3=new Employee(3,"C",1900);
		Employee e4=new Employee(4,"D",2300);
		Employee e5=new Employee(5,"E",1800);
		ArrayList<Employee> l=new ArrayList<Employee>();
		l.add(e1);
		l.add(e2);
		l.add(e3);
		l.add(e4);
		l.add(e5);
		for (Employee emp: l) 
        { 
            System.out.println( emp.getEid()+ " " + 
                               emp.getEname() + " " + 
                               emp.getSalary()); 
        } 
		do {
			System.out.println("press 1 to add an element  and  return the index of That element:");
			System.out.println("press 2 to find a particular element is present in arraylist or not:");
			System.out.println("press 3 to remove a given element from arraylist:");
			System.out.println("press 4 to sort the arrayList in ascending order:");
			System.out.println("press 5 to sort the arrayList in descending order:");
			System.out.println("press 6 to replace all the occurances of a particular element from the arraylist");
			System.out.println("please enter your choice:");
			int ch=t.nextInt();
			switch(ch)
			{
			case 1:
			      Employee n=new Employee(6,"F",6000);
			      ArrayList<Employee> k=Add_N_Return(l,n);
			      for (Employee em:k ) 
			        { 
			            System.out.println(em.getEid() + " " + 
			                               em.getEname() + " " + 
			                               em.getSalary()); 
			        } 
				 break;
			case 2:System.out.println("Give the element to search");
			       //Employee e=new Employee(2,"B",2000);
			       int k1=Search(l,e2);
			       if(k1==-1)
			       {
			    	   System.out.println("Element Not Found:");
			    	   
			       }
			       else {
			    	   System.out.println("Element Found:");
			       }
			       
			  break;
			case 3:ArrayList<Employee> x=Remove(l,e1);
			for (Employee v: x) 
	        { 
	            System.out.println(v.getEid() + " " + 
	                               v.getEname()+ " " + 
	                               v.getSalary()); 
	        } 
			       
				  break;
			case 4:System.out.println("Sorted in ascending Order ");
			       ArrayList<Employee> res1=SortIt(l);
			       for (Employee u: res1) 
			        { 
			            System.out.println(u.getEid() + " " + 
			                               u.getEname() + " " + 
			                               u.getSalary()); 
			        } 
				  break;
			case 5:System.out.println("Sorted in descending order ");
			     ArrayList<Employee> res2=sortDesc(l);
			     for (Employee w: res2) 
		        { 
		            System.out.println(w.getEid() + " " + 
		                               w.getEname() + " " + 
		                               w.getSalary()); 
		        } 
			
				  break;
			case 6:System.out.println("Give The element to replace:");
			       Employee r=new Employee(8,"Hari",2500);
			     

			       ArrayList<Employee> res3=ReplaceAll(l,e3,r);
			       for (Employee o: res3) 
			        { 
			            System.out.println(o.getEid() + " " + 
			                               o.getEname() + " " + 
			                               o.getSalary()); 
			        } 
			       break;
			case 7:s=1;
			       break;
			default:System.out.println("Invalid input try again please:");
			      break;
			}



				
					
				}while(s!=1);
		



	}
	   static ArrayList<Employee> Remove(ArrayList<Employee> l, Employee e1) {
		
		l.remove(e1);
		return l;
	}
	static ArrayList<Employee> ReplaceAll(ArrayList<Employee> l, Employee e3, Employee r) {
		Collections.replaceAll(l, e3, r);
		return l;
	}
	static ArrayList<Employee> sortDesc(ArrayList<Employee> l) {
	
		Collections.sort(l, Collections.reverseOrder());
		return l;
	}
	static ArrayList<Employee> SortIt(ArrayList<Employee> l) {
		Collections.sort(l);
		return l;
	}
	static int Search(ArrayList<Employee> l, Employee e) {
		return l.indexOf(e);
		
	}
	static ArrayList<Employee> Add_N_Return(ArrayList<Employee> l, Employee n) {
		l.add(n);
		return l;
	}
}
