package Exception_Handling;


public class ThrowsExecp{ 
	
	public static void main(String args[]){ 
		
		String s="Hello";
		System.out.println(s.length());
		String str = null; 
		System.out.println(str.length()); 

		
	} 
} 

