package Exception_Handling;

import java.util.Scanner;

//Java program to demonstrate ArithmeticException 
public class ArithmeticException_Demo 
{ 
	public static void main(String args[]) throws Exception 
	
	{ 
		Scanner t=new Scanner(System.in);
		System.out.println("Give The Size of Both The Arrays:");
		int n=t.nextInt();
		int[] a1=new int[n];
		int[] a2=new int[n];
		System.out.println("Enter the Elements of First Array:");
		for(int i=0;i<n;i++)
		{
			a1[i]=t.nextInt();
			
		}
		System.out.println("Enter the Elements of Second Array:");
		for(int j=0;j<n;j++)
		{
			a2[j]=t.nextInt();
		}
		int[] sum=new int[n];
		
		
		
		
		
		
		try { for(int i=0;i<n;i++)
		{
			sum[i]=a1[i]+a2[i];
			if(sum[i]<0)
			{
				fun();
				
			}
		
			
		}
			
		} 
		catch(Exception e) { 
			System.out.println(e);
			
		} 
		finally { for(int i=0;i<n&& sum[i]!='\0';i++)
		{
			System.out.println(sum[i]);
		}
			
	
		}
		
	}

	 static void fun() throws Exception 
	    { 
	        try
	        { 
	          throw new Exception("NegativeSumException"); 
	        } 
	        catch(Exception e) 
	        { 
	            
	            throw e; // rethrowing the exception 
	        } 
	    } 
} 

