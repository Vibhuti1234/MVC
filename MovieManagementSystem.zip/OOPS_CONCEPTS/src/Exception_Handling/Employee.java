package Exception_Handling;

public class Employee {
	private int eid;
	private String ename;
	private double esal;
	public Employee(int eid,String ename,double esal)
	{this.eid=eid;
	this.ename=ename;
	this.esal=esal;
	
		
	}
	public int getEid() {
		return eid;
	}
	public String getEname() {
		return ename;
	}

	public double getEsal() {
		return esal;
	}

	

}
