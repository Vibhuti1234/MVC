package Exception_Handling;

import java.util.ArrayList;
import java.util.Scanner;

public class Employee_Application {
	public static void main(String args[])
	{
		Scanner t=new Scanner(System.in);
		ArrayList<Employee> a=new ArrayList<Employee>();
		System.out.println("Enter The No of Employee");
		int n=t.nextInt();
		for(int i=0;i<n;i++)
		{
			
			try {
				System.out.println("Enter The Employee Id:");
				int eid=t.nextInt();
				t.nextLine();
				System.out.println("Enter the Employee Name:");
				String ename=t.nextLine();
				System.out.println("Enter the Salary:");
				double esal=t.nextDouble();
				t.nextLine();
				if(esal<0)
				{
					throw new Exception("NegativeSalaryException");
				}
				else {
					Employee e=new Employee(eid,ename,esal);
					a.add(e);
				  System.out.println("Employee Added Successfully:");
				}
			}
			catch(Exception e){
				System.out.println("You Have Entered an Invalid Salary:"); 
			}
			
			
		}
		for(Employee x:a)
		{
			System.out.println(x.getEid()+" "+x.getEname()+" "+x.getEsal());
		}
		
		
	}

}
