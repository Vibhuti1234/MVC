import java.util.*;
import java.lang.*;
import java.io.*;
interface one{
	public void print_geek();
}
interface two{
	public void print_for();
}
interface three extends one,two
{
	public void print_geek();
}
class child implements three{
	public void print_geek()
	{
		System.out.println("Geek");
	}
	public void print_for()
	{
		System.out.println("For");
	}
}
public class Multiple_Inheritance {
	public static void main(String args[])
	{ child ob =new child();
	ob.print_geek();
	ob.print_for();
	ob.print_geek();
		
	}

}
 