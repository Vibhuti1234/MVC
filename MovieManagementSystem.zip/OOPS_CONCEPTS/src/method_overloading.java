
 class overloading {
	static int multiply(int a,int b)
	{
		return a*b;
	}
	static double  multiply(double a,double b)
	{
		return a*b;
	}
	static int multiply(int a,int b,int c)
	{
		return a*b*c;
	}

}
 //by using different no of arguments:
 
public class method_overloading{
	public static void main(String args[])
	{
		System.out.println("Multiplication 1 is :"+overloading.multiply(9,7));
		System.out.println("Multiplication 2 is :"+overloading.multiply(7.8, 5.9));
		System.out.println("Multiplication 3 is :"+overloading.multiply(3, 5, 4));
	}
}
