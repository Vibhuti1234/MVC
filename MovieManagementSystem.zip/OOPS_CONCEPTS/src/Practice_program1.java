import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Scanner;

public class Practice_program1 {
	public static void main(String args[])
	{
Scanner t=new Scanner(System.in);

ArrayList<Integer> a=new ArrayList<Integer>();
System.out.println("Give The elements of array:");
for(int i=0;i<10;i++)
{   
	int n=t.nextInt();
	a.add(n);
}
HashSet<Integer> h=new HashSet<Integer>(a);
for (Integer temp : h){
	System.out.println(temp);
}
t.close();

}
}