import java.util.Scanner;

class customerdetails {
	String userName;
	String userAdress;

	accountdetails[] a;

	public customerdetails(String uname, String uadd, accountdetails[] a) {
		this.userName = uname;
		this.userAdress = uadd;
		this.a = a;
	}

	public String getUserName() {
		return userName;
	}

	public String getUserAdress() {
		return userAdress;
	}

	public accountdetails[] getAccountDetails() {
		return a;
	}

}

class accountdetails {
	public accountdetails(int ano, String atype, String icode, double bal) {
		this.accountNumber = ano;
		this.accountType = atype;
		this.ifscCode = icode;
		this.balance = bal;
	}

	int accountNumber;
	String accountType;
	String ifscCode;
	double balance;

	public int getAccountNo() {
		return accountNumber;
	}

	public String getAccountType() {
		return accountType;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public double getBalance() {
		return balance;
	}
}

public class coding_challenge1 {
	static int s = 0;
	static double bal;

	public static void main(String args[]) {
		Scanner t = new Scanner(System.in);
		System.out.println("Give the no of Users:");
		int n = t.nextInt();
		t.nextLine();
		customerdetails[] c = new customerdetails[n];
		for (int i = 0; i < n; i++) {
			System.out.println("Give User name of " + (i + 1));
			String uname = t.nextLine();
			System.out.println("Give User address of User " + (i + 1));
			String uadd = t.nextLine();
			System.out.println("Give Account Details of User" + (i + 1));
			System.out.println("Enter the No of Bank Accounts That User " + (i + 1) + "have");
			int m = t.nextInt();
			t.nextLine();
			accountdetails[] a = new accountdetails[m];
			for (int j = 0; j < m; j++) {
				System.out.println("Give Account no of " + (i + 1) + "Account");
				int ano = t.nextInt();
				t.nextLine();
				System.out.println("Mention the type of Account:");
				String atype = t.nextLine();
				System.out.println("Give the IFSC Code:");
				String icode = t.nextLine();
				System.out.println("Give the balance:");
				double bal = t.nextDouble();
				t.nextLine();
				a[j] = new accountdetails(ano, atype, icode, bal);
			}
			c[i] = new customerdetails(uname, uadd, a);
		}
		do {
			System.out.println("Press 1 to Add a New Customer:");
			System.out.println("Press 2 to view the balance of an entered bankAccount:");
			System.out.println("Press 3 to view all the Accounts with complete details of a particular UserName:");
			System.out.println("Press 4 to view Accounts in a sorted order as per their Balance");
			System.out.println("Press 5 to Exit");
			System.out.println("Enter your choice:");
			int ch = t.nextInt();
			t.nextLine();
			switch (ch) {
			case 1:
				System.out.println("Enter the details of customer");
				System.out.println("Enter the name  of customer");
				String cname = t.nextLine();
				System.out.println("Enter the address of customer");
				String cadd = t.nextLine();
				System.out.println("Enter the no of accounts of New Customer:");
				int cno = t.nextInt();
				accountdetails[] acc = new accountdetails[cno];
				for (int i = 0; i < cno; i++) {
					System.out.println("Enter the account no:");
					int accno = t.nextInt();
					t.nextLine();
					System.out.println("Enter the acctype:");
					String atype = t.nextLine();
					System.out.println("Enter the Ifsc code");
					String icode = t.nextLine();
					System.out.println("Enter the balance:");
					double bal = t.nextDouble();
					acc[i] = new accountdetails(accno, atype, icode, bal);
				}
				customerdetails d = new customerdetails(cname, cadd, acc);
				break;
			case 2:
				System.out.println("Give Account No:");
				int accno = t.nextInt();
				double res_bal = getBalance(c, accno);
				System.out.println(res_bal);
				break;
			case 3:
				System.out.println("Give The userName");
				String uname = t.nextLine();
				getAccountDetailsForUserName(c, uname);
				break;
			case 4:
				accountdetails[] ar = BubbleSort(c);
				for (int i = 0; i < ar.length; i++) {
					System.out.println(ar[i].getAccountNo() + " " + ar[i].getAccountType() + " " + ar[i].getIfscCode()
							+ " " + ar[i].getBalance());
				}
				break;
			case 5:
				s = 1;
				break;
			default:
				System.out.println("Invalid Input Please  Try Again Later");
				break;

			}

		} while (s != 1);

	}

	static accountdetails[] BubbleSort(customerdetails[] c) {
		int sum = 0;
		for (int i = 0; i < c.length; i++) {
			sum = sum + c[i].getAccountDetails().length;
		}
		accountdetails[] a = new accountdetails[sum];
		int k = 0;
		for (int i = 0; i < c.length; i++) {
			for (int j = 0; j < c[i].getAccountDetails().length; j++) {
				a[k] = c[i].getAccountDetails()[j];
				k++;
			}
		}
		accountdetails[] res = RealBubbleSort(a);
		return res;

	}

	static accountdetails[] RealBubbleSort(accountdetails[] a) {
		for (int i = 0; i < a.length - 1; i++) {
			for (int j = 0; j < a.length - i - 1; j++) {
				if (a[j].getBalance() > a[j + 1].getBalance()) {
					accountdetails temp;
					temp = a[j];
					a[j] = a[j + 1];
					a[j + 1] = temp;
				}
			}
		}
		return a;
	}

	static void getAccountDetailsForUserName(customerdetails[] c, String uname) {
		for (int i = 0; i < c.length; i++) {

			if (c[i].getUserName().equals(uname)) {
				for (int j = 0; j < c[i].getAccountDetails().length; j++) {
					System.out.println(c[i].getAccountDetails()[j].getAccountNo() + " "
							+ c[i].getAccountDetails()[j].getAccountType() + " "
							+ c[i].getAccountDetails()[j].getIfscCode() + " "
							+ c[i].getAccountDetails()[j].getBalance());
				}

			}
		}

	}

	static double getBalance(customerdetails[] c, int accno) {

		for (int i = 0; i < c.length; i++) {
			for (int j = 0; j < c[i].getAccountDetails().length; j++) {
				if (c[i].getAccountDetails()[j].getAccountNo() == accno) {
					bal = (c[i].getAccountDetails()[j].getBalance());
				}
			}
		}
		return bal;

	}

}
