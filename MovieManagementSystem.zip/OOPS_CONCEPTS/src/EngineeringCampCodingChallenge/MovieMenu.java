package EngineeringCampCodingChallenge;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

public class MovieMenu {
	static int s=0;
	public static void main(String args[])
	{
		Scanner t=new Scanner(System.in);
		HashSet<Movie> h=new HashSet<Movie>();
		System.out.println("Enter The No of Movies:");
		int n=t.nextInt();
		
		for(int i=0;i<n;i++ )
		{
			System.out.println("Enter The Movie Id of"+(i+1));
			int mid=t.nextInt();
			t.nextLine();
			System.out.println("Enter The MOvie Name of "+(i+1));
			String mname=t.nextLine();
			System.out.println("Enter the Number of Actors:");
			int na=t.nextInt();
			HashSet<Actor> a=new HashSet<Actor>();

			for(int j=0;j<na;j++)
			{
				System.out.println("Enter The Actor Id of"+(j+1));
				int aid=t.nextInt();
				t.nextLine();
				System.out.println("Enter The Actor Name of"+(j+1));
				String aname=t.nextLine();
				System.out.println("Enter The no of Awards Won By Actor"+(j+1));
				int naw=t.nextInt();
				t.nextLine();
				ArrayList<String> al=new ArrayList<String>();

				for(int k=0;k<naw;k++)
				{
					System.out.println("Enter The name of"+(k+1)+"Award");
					String awname=t.nextLine();
					al.add(awname);
					
				}
				Actor ob=new Actor(aid,aname,al);
				a.add(ob);
				
				
			}
			Movie m=new Movie(mid,mname,a);
			h.add(m);	
		}
		System.out.println("priting Movies");
		for(Movie m:h)
		{
		System.out.println(m);
		}
		
		
		do {System.out.println("Press 1 to Dispaly All The Movies whch has been Acted By a Particular Actor:");
		    System.out.println("Press 2 To Display all Awards That a particular Actor Has Got:");
		    System.out.println("Press 3 to Exit:");
		    System.out.println("Please Enter Your Choice:");
		    int ch=t.nextInt();
		    t.nextLine();
		    switch(ch)
		    {
		    case 1:
		    	break;
		    case 2:System.out.println("Give The Name Of Actor:"); 
		       String Actor=t.nextLine();
		    getAllAward(h,Actor);
		    
		    	
		    
		    	  break;
		    case 3:
		    	  s=1;
		    	  break;
		    default:System.out.println("Invalid Choice Try Again:");
		           break;
		    }
			
		}while(s!=1);
		
		
	}
	private static void getAllAward(HashSet<Movie> h, String actor) {
//		Iterator<Movie> i = h.iterator();
//		ArrayList<String> u=new ArrayList<String>();
//        while (i.hasNext()) 
//        {    HashSet<Actor> ac=i.next().getOb();
//              Iterator<Actor> j=ac.iterator();
//        	while(j.hasNext())
//        	{
//        		if(j.getActorName().equals(actor))
//        		{ 
////        			u.addAll(j.next().getAl());
//        			System.out.println(j.next().getAl());
//        		}
//        	}
//        }
        
        for(Movie movie: h) {
//        	HashSet<Actor> h=movie.getOb();
        	for(Actor act: movie.getOb()) {
        		if(act.getActorName().equals(actor))
        			System.out.println(act.getAl());
        	}
        }
       

	

}
}