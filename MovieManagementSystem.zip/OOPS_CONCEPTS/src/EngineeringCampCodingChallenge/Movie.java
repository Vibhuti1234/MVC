package EngineeringCampCodingChallenge;

import java.util.HashSet;

public class Movie {
	private int MovieId;
	private String MovieName;
	private HashSet<Actor> ob;
	public Movie(int MovieId,String MovieName,HashSet<Actor> ob)
	{
		this.MovieId=MovieId;
		this.MovieName=MovieName;
		this.ob=ob;
	}
	public int getMovieId() {
		return MovieId;
	}
	public String getMovieName() {
		return MovieName;
	}
	
	public HashSet<Actor> getOb() {
		return ob;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + MovieId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movie other = (Movie) obj;
		if (MovieId != other.MovieId)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Movie [MovieId=" + MovieId + ", MovieName=" + MovieName + ", ob=" + ob + "]";
	}
	
	
	

}
