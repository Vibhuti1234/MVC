package EngineeringCampCodingChallenge;

import java.util.ArrayList;

public class Actor {
	private int actorId;
	private String actorName;
	private ArrayList<String> Awards;
	public Actor(int actorId,String actorName,ArrayList<String> Awards)
	{this.actorId=actorId;
	this.actorName=actorName;
	this.Awards=Awards;			
		
	}
	public int getActorId() {
		return actorId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + actorId;
		result = prime * result + ((actorName == null) ? 0 : actorName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Actor other = (Actor) obj;
		if (actorId != other.actorId)
			return false;
		if (actorName == null) {
			if (other.actorName != null)
				return false;
		} else if (!actorName.equals(other.actorName))
			return false;
		return true;
	}
	public String getActorName() {
		return actorName;
	}
	public ArrayList<String> getAl() {
		return Awards;
	}
	@Override
	public String toString() {
		return "Actor [actorId=" + actorId + ", actorName=" + actorName + ", Awards=" + Awards + "]";
	}
	
	

}
