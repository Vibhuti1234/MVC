class parent{
	void display()
	{
		System.out.println("Parent");
	}
}
class child1 extends parent{
	void display()
	{
		System.out.println("child1");
		
	}
}
class child2 extends parent{
	void display()
	{
		System.out.println("child2");}
	}
public class runtime_polymorphism {
	public static void main(String args[])
	{
		parent p;
		p=new child1();
		p.display();
		p=new child2();
		p.display();
	}
	

}
