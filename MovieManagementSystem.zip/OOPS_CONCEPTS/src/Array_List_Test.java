import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Array_List_Test {
	static int s=0;
public static void main(String args[])
{   Scanner t=new Scanner(System.in);
	ArrayList<Integer> alist=new ArrayList<Integer>();
	alist.add(2);
	alist.add(3);
	alist.add(45);
	alist.add(89);
	alist.add(57);
	alist.add(7);
	alist.add(81);
	System.out.println(alist);
	do {
System.out.println("press 1 to add an element  and  return the index of That element:");
System.out.println("press 2 to find a particular element is present in arraylist or not:");
System.out.println("press 3 to remove a given element from arraylist:");
System.out.println("press 4 to sort the arrayList in ascending order:");
System.out.println("press 5 to sort the arrayList in descending order:");
System.out.println("press 6 to replace all the occurances of a particular element from the arraylist");
System.out.println("please enter your choice:");
int ch=t.nextInt();
switch(ch)
{
case 1:System.out.println("Give the element to Add:");
      int n=t.nextInt();
      int k=Add_N_Return(alist,n);
      System.out.println(k);
	 break;
case 2:System.out.println("Give the element to search");
       int m=t.nextInt();
       int k1=Search(alist,m);
       if(k1==-1)
       {
    	   System.out.println("Element Not Found:");
    	   
       }
       else {
    	   System.out.println("Element Found:");
       }
       
  break;
case 3:System.out.println("Give an element to remove:");
       int x=t.nextInt();
       int k2=Search(alist,x);
       if(k2==-1)
       {
    	   System.out.println("Element is already not there:");
       }
       else { 
    	   ArrayList<Integer> res=Remove(alist,x);
    	   System.out.println("The Updated List is "+res);
       }
	  break;
case 4:System.out.println("Unsorted List "+alist);
       ArrayList<Integer> res1=SortIt(alist);
       System.out.println("Sorted List "+res1);
	  break;
case 5:System.out.println("Sorted in descending order "+SortDesc(alist));
	  break;
case 6:System.out.println("Give The element to replace:");
       int r=t.nextInt();
       System.out.println("Before replacing "+alist);

       ArrayList<Integer> res3=ReplaceAll(alist,r);
       System.out.println("after replacing "+res3);
       break;
case 7:s=1;
       break;
default:System.out.println("Invalid input try again please:");
      break;
}



	
		
	}while(s!=1);
	

}
   static ArrayList<Integer> ReplaceAll(ArrayList<Integer> alist, int r) {
	Collections.replaceAll(alist, r, 50);
	return alist ;
}
static ArrayList<Integer> SortDesc(ArrayList<Integer> alist) {
	Collections.sort(alist, Collections.reverseOrder());
	return alist;
}
static ArrayList<Integer> SortIt(ArrayList<Integer> alist) {
	
	Collections.sort(alist);
	return alist;
}
static ArrayList<Integer> Remove(ArrayList<Integer> alist, int x) {
	alist.remove(x);
	return alist;
}
static int Search(ArrayList<Integer> alist, int m) {
	
	return alist.indexOf(m);
}
static int Add_N_Return(ArrayList<Integer> alist, int n) {
	alist.add(n);
	return alist.indexOf(n);
	
}
}