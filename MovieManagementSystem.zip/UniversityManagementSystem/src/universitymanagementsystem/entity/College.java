package universitymanagementsystem.entity;

public class College {
private int collegeId;
private String collegeName;
private double collegeRating;
private int UID;
public College() {
	super();
	// TODO Auto-generated constructor stub
}
public College(int collegeId, String collegeName, double collegeRating, int uID) {
	super();
	this.collegeId = collegeId;
	this.collegeName = collegeName;
	this.collegeRating = collegeRating;
	UID = uID;
}
public int getCollegeId() {
	return collegeId;
}
public void setCollegeId(int collegeId) {
	this.collegeId = collegeId;
}
public String getCollegeName() {
	return collegeName;
}
public void setCollegeName(String collegeName) {
	this.collegeName = collegeName;
}
public double getCollegeRating() {
	return collegeRating;
}
public void setCollegeRating(double collegeRating) {
	this.collegeRating = collegeRating;
}
public int getUID() {
	return UID;
}
public void setUID(int uID) {
	UID = uID;
}
@Override
public String toString() {
	return "College [collegeId=" + collegeId + ", collegeName=" + collegeName + ", collegeRating=" + collegeRating
			+ ", UID=" + UID + "]";
}

}
