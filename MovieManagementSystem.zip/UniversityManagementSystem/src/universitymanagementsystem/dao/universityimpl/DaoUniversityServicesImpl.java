package universitymanagementsystem.dao.universityimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import universitymanagementsystem.dao.DaoUniversityServices;
import universitymanagementsystem.entity.University;
import universitymanagementsystem.exception.DaoCollegeException;
import universitymanagementsystem.exception.DaoException;
import universitymanagementsystem.exception.DaoUniversityException;
import universitymanagementsystem.exception.UtilityException;
import universitymanagementsystem.utility.impl.DbConnectivityImpl;


public class DaoUniversityServicesImpl implements DaoUniversityServices{

	@Override
	public void addUniversity(University university) throws DaoUniversityException {
		// TODO Auto-generated method stub
		Connection connection;
		try {
			connection=DbConnectivityImpl.getConnection();
			String query="insert into university values (?,?)";
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			preparedStatement.setInt(1, university.getUniversityId());;
			preparedStatement.setString(2,university.getUniversityName());
			preparedStatement.executeUpdate();
		}
		catch(UtilityException e) {
			throw new DaoUniversityException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoUniversityException("Something wrong in sql Queries",e);
		}
		
	}

	@Override
	public List<University> getAllUniversities() throws DaoUniversityException {
		List<University> universities=new ArrayList<>();
		Connection connection;
		try {
			connection=DbConnectivityImpl.getConnection();
			String query="select * from university";
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
		      universities.add(new  University(rs.getInt(1),rs.getString(2)));
			}
		}
		catch(UtilityException e) {
			throw new DaoUniversityException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoUniversityException("Something wrong in sql Queries",e);
		}
		return universities;
	}

	@Override
	public void deleteUniversity(int universityId) throws DaoUniversityException {
		Connection connection;
		try {
			connection=DbConnectivityImpl.getConnection();
			String query="delete universityId,universityName,collegeId,collegeName,collegeRating,UID from college c inner join"
					+ "university u on c.UID=u.universityId where universityId=?";
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			preparedStatement.setInt(1,universityId);
			ResultSet rs=preparedStatement.executeQuery();
		}
		catch(UtilityException e) {
			throw new DaoUniversityException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoUniversityException("Something wrong in sql Queries",e);
		}
		
	}

	@Override
	public boolean checkUniversity(int universityId) throws DaoUniversityException {
	
		    Connection connection;
		    try {
		    	connection=DbConnectivityImpl.getConnection();
		    	 String query="select * from university where universityId=?";
		    	 PreparedStatement preparedStatement=connection.prepareStatement(query);
		    	 preparedStatement.setInt(1,universityId);
		    	 ResultSet rs=preparedStatement.executeQuery();
		    	 if(rs.next())
		    	 {
		    		 return true;
		    	 }	 
		    }
		    catch(UtilityException e) {
				throw new DaoUniversityException("Something Wrong in Utility class",e);
			}
			catch(SQLException e) {
				throw new DaoUniversityException("Something wrong in sql Queries",e);
			}
		    return false;
			
	}

	@Override
	public boolean checkUniversity(String universityName) throws DaoUniversityException {
		// TODO Auto-generated method stub
		Connection connection;
	    try {
	    	connection=DbConnectivityImpl.getConnection();
	    	 String query="select * from university where universityName=?";
	    	 PreparedStatement preparedStatement=connection.prepareStatement(query);
	    	 preparedStatement.setString(1,universityName);
	    	 ResultSet rs=preparedStatement.executeQuery();
	    	 if(rs.next())
	    	 {
	    		 return true;
	    	 }	 
	    }
	    catch(UtilityException e) {
			throw new DaoUniversityException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoUniversityException("Something wrong in sql Queries",e);
		}
	    return false;
		
	}
		
	}


