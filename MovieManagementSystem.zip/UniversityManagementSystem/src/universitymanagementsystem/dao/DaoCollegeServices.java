package universitymanagementsystem.dao;

import java.util.List;

import universitymanagementsystem.entity.College;
import universitymanagementsystem.exception.DaoCollegeException;
import universitymanagementsystem.exception.DaoUniversityException;

public interface DaoCollegeServices {
	public void addCollege(College college) throws DaoCollegeException;
    public List<College> getAllColleges() throws DaoCollegeException;
    public List<College> getColleges(int universityId) throws DaoCollegeException;
    public void deleteCollege(int collegeId) throws DaoCollegeException;
    public boolean checkCollege(int collegeId) throws DaoCollegeException;
    public boolean checkCollege(String collegeName) throws DaoCollegeException;
}
