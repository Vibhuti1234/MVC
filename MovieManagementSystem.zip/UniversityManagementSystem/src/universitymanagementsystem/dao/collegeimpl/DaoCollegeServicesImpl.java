package universitymanagementsystem.dao.collegeimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import universitymanagementsystem.dao.DaoCollegeServices;
import universitymanagementsystem.entity.College;
import universitymanagementsystem.exception.DaoCollegeException;
import universitymanagementsystem.exception.DaoUniversityException;
import universitymanagementsystem.exception.UtilityException;
import universitymanagementsystem.utility.impl.DbConnectivityImpl;


public class DaoCollegeServicesImpl implements DaoCollegeServices{

	@Override
	public void addCollege(College college) throws DaoCollegeException {
		Connection connection;
		try {
			connection=DbConnectivityImpl.getConnection();
			String query="insert into college  values (?,?,?,?)";
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			preparedStatement.setInt(1, college.getCollegeId());;
			preparedStatement.setString(2,college.getCollegeName());
			preparedStatement.setDouble(3,college.getCollegeRating());
			preparedStatement.setInt(4,college.getUID());
			preparedStatement.executeUpdate();
		}
		catch(UtilityException e) {
			throw new DaoCollegeException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoCollegeException("Something wrong in sql Queries",e);
		}
		
		
	}

	@Override
	public List<College> getAllColleges() throws DaoCollegeException {
		List<College> colleges=new ArrayList<>();
		Connection connection;
		try {
			connection=DbConnectivityImpl.getConnection();
			String query="select * from college";
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				colleges.add(new College(rs.getInt(1),rs.getString(2),rs.getDouble(3),rs.getInt(4)));
			}
		}
		catch(UtilityException e) {
			throw new DaoCollegeException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoCollegeException("Something wrong in sql Queries",e);
		}
		return colleges;
	}

	@Override
	public List<College> getColleges(int universityId) throws DaoCollegeException {
		Connection connection;
		List<College> colleges;
		try {
			connection=DbConnectivityImpl.getConnection();
			colleges=new ArrayList<>();
			String query="select * from college c inner join university u on c.UID=u.universityId where universityId=?";
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			preparedStatement.setInt(1,universityId);
			ResultSet rs=preparedStatement.executeQuery();
			while(rs.next())
			{
				College col=new College(rs.getInt(1),rs.getString(2),rs.getDouble(3),rs.getInt(4));
				colleges.add(col);
			}
			
		}
		catch(UtilityException e) {
			throw new DaoCollegeException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoCollegeException("Something wrong in sql Queries",e);
		}
		return colleges;
	}

	@Override
	public void deleteCollege(int collegeId) throws DaoCollegeException {
		// TODO Auto-generated method stub
		Connection connection;
		try {
			connection=DbConnectivityImpl.getConnection();
			String query="delete  from college where collegeId=?";
			PreparedStatement preparedStatement=connection.prepareStatement(query);
			preparedStatement.setInt(1,collegeId);
			ResultSet rs=preparedStatement.executeQuery();
		}
		catch(UtilityException e) {
			throw new DaoCollegeException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoCollegeException("Something wrong in sql Queries",e);
		}
		
	}

	@Override
	public boolean checkCollege(int collegeId) throws DaoCollegeException {
		 Connection connection;
		    try {
		    	connection=DbConnectivityImpl.getConnection();
		    	 String query="select * from college where collegeId=?";
		    	 PreparedStatement preparedStatement=connection.prepareStatement(query);
		    	 preparedStatement.setInt(1,collegeId);
		    	 ResultSet rs=preparedStatement.executeQuery();
		    	 if(rs.next())
		    	 {
		    		 return true;
		    	 }	 
		    }
		    catch(UtilityException e) {
				throw new DaoCollegeException("Something Wrong in Utility class",e);
			}
			catch(SQLException e) {
				throw new DaoCollegeException("Something wrong in sql Queries",e);
			}
		    return false;
			
	}

	@Override
	public boolean checkCollege(String collegeName) throws DaoCollegeException {
		Connection connection;
	    try {
	    	connection=DbConnectivityImpl.getConnection();
	    	 String query="select * from college where collegeName=?";
	    	 PreparedStatement preparedStatement=connection.prepareStatement(query);
	    	 preparedStatement.setString(1,collegeName);
	    	 ResultSet rs=preparedStatement.executeQuery();
	    	 if(rs.next())
	    	 {
	    		 return true;
	    	 }	 
	    }
	    catch(UtilityException e) {
			throw new DaoCollegeException("Something Wrong in Utility class",e);
		}
		catch(SQLException e) {
			throw new DaoCollegeException("Something wrong in sql Queries",e);
		}
	    return false;
		
	}

}
