package universitymanagementsystem.dao;

import java.util.List;

import universitymanagementsystem.entity.University;
import universitymanagementsystem.exception.DaoUniversityException;

public interface DaoUniversityServices {
	public void addUniversity(University university) throws DaoUniversityException;
    public List<University> getAllUniversities() throws DaoUniversityException;
    public void deleteUniversity(int universityId) throws DaoUniversityException;
    public boolean checkUniversity(int universityId) throws DaoUniversityException;
    public boolean checkUniversity(String universityName) throws DaoUniversityException;
 }
