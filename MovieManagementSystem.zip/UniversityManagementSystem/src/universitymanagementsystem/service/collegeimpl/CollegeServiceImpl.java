package universitymanagementsystem.service.collegeimpl;

import java.util.List;

import universitymanagementsystem.dao.DaoCollegeServices;
import universitymanagementsystem.dao.collegeimpl.DaoCollegeServicesImpl;
import universitymanagementsystem.entity.College;
import universitymanagementsystem.exception.CollegeServiceException;
import universitymanagementsystem.exception.DaoCollegeException;
import universitymanagementsystem.exception.DaoUniversityException;
import universitymanagementsystem.service.CollegeService;

public class CollegeServiceImpl implements CollegeService{
     private DaoCollegeServices dao=new DaoCollegeServicesImpl();
	@Override
	public void addCollege(College college) throws CollegeServiceException {
		try {
			dao.addCollege(college);
		}
		catch(DaoCollegeException e)
		{
			throw new CollegeServiceException(" ",e);
		}
	}

	@Override
	public List<College> getAllColleges() throws CollegeServiceException {
		try {
			return dao.getAllColleges();
		}
		catch(DaoCollegeException e)
		{
			throw new CollegeServiceException(" ",e);
		}
	}

	@Override
	public List<College> getColleges(int universityId) throws CollegeServiceException {
		// TODO Auto-generated method stub
		try {
			return dao.getColleges(universityId);
		}
		catch(DaoCollegeException e)
		{
			throw new CollegeServiceException(" ",e);
		}
	}

	@Override
	public void deleteCollege(int collegeId) throws CollegeServiceException {
		// TODO Auto-generated method stub
		try {
			dao.deleteCollege(collegeId);
		}
		catch(DaoCollegeException e)
		{
			throw new CollegeServiceException(" ",e);
		}
		
	}

	@Override
	public boolean checkCollege(int collegeId) throws CollegeServiceException {
		// TODO Auto-generated method stub
		try {
			return dao.checkCollege(collegeId);
		}
		catch(DaoCollegeException e)
		{
			throw new CollegeServiceException(" ",e);
		}
		
	}

	@Override
	public boolean checkCollege(String collegeName) throws CollegeServiceException {
		try {
			return dao.checkCollege(collegeName);
		}
		catch(DaoCollegeException e)
		{
			throw new CollegeServiceException(" ",e);
		}
	}

}
