package universitymanagementsystem.service.universityimpl;

import java.util.List;

import universitymanagementsystem.dao.DaoUniversityServices;
import universitymanagementsystem.dao.universityimpl.DaoUniversityServicesImpl;
import universitymanagementsystem.entity.University;
import universitymanagementsystem.exception.DaoUniversityException;
import universitymanagementsystem.exception.UniversityServiceException;
import universitymanagementsystem.service.UniversityService;

public class UniversityServiceImpl implements UniversityService {
    private DaoUniversityServices dao=new DaoUniversityServicesImpl();
	@Override
	public void addUniversity(University university) throws UniversityServiceException {
		try {
			dao.addUniversity(university);
		}
		catch(DaoUniversityException e)
		{
			throw new UniversityServiceException(" ",e);
		}
		
	}

	@Override
	public List<University> getAllUniversities() throws UniversityServiceException {
		
		try {
			return dao.getAllUniversities();
		}
		catch(DaoUniversityException e)
		{
			throw new UniversityServiceException(" ",e);
		}
	}

	@Override
	public void deleteUniversity(int universityId) throws UniversityServiceException {
		try {
			dao.deleteUniversity(universityId);
		}
		catch(DaoUniversityException e)
		{
			throw new UniversityServiceException(" ",e);
		}
	}

	@Override
	public boolean checkUniversity(int universityId) throws UniversityServiceException {
	     try {
	    	 return dao.checkUniversity(universityId);
	     }
	     catch(DaoUniversityException e)
	     {
	    	 throw new UniversityServiceException(" ",e);
	     }
	}

	@Override
	public boolean checkUniversity(String universityName) throws UniversityServiceException {
		try {
			return dao.checkUniversity(universityName);
		}
		catch(DaoUniversityException e)
		{
			throw new UniversityServiceException(" ",e);
		}
	}

}
