package universitymanagementsystem.service;

import java.util.List;

import universitymanagementsystem.entity.University;
import universitymanagementsystem.exception.DaoUniversityException;
import universitymanagementsystem.exception.UniversityServiceException;

public interface UniversityService {
	public void addUniversity(University university) throws UniversityServiceException;
	public List<University> getAllUniversities() throws UniversityServiceException;
    public void deleteUniversity(int universityId) throws UniversityServiceException;
    public boolean checkUniversity(int universityId) throws UniversityServiceException;
    public boolean checkUniversity(String universityName) throws UniversityServiceException;

}
