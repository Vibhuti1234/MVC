package universitymanagementsystem.service;

import java.util.List;

import universitymanagementsystem.entity.College;
import universitymanagementsystem.exception.CollegeServiceException;
import universitymanagementsystem.exception.DaoCollegeException;
import universitymanagementsystem.exception.DaoUniversityException;

public interface CollegeService {
	public void addCollege(College college) throws CollegeServiceException;
    public List<College> getAllColleges() throws CollegeServiceException;
    public List<College> getColleges(int universityId) throws CollegeServiceException ;
    public void deleteCollege(int collegeId) throws CollegeServiceException;
    public boolean checkCollege(int collegeId) throws CollegeServiceException;
    public boolean checkCollege(String collegeName) throws CollegeServiceException;

}
