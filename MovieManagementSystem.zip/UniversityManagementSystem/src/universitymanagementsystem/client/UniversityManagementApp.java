package universitymanagementsystem.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import universitymanagementsystem.entity.College;
import universitymanagementsystem.entity.University;
import universitymanagementsystem.exception.CollegeServiceException;
import universitymanagementsystem.exception.DuplicateCollegeNameException;
import universitymanagementsystem.exception.DuplicateUniversityNameException;
import universitymanagementsystem.exception.NoSuchCollegeException;
import universitymanagementsystem.exception.NoSuchUniversityException;
import universitymanagementsystem.exception.RatingOutOfBoundException;
import universitymanagementsystem.exception.UniversityServiceException;
import universitymanagementsystem.service.CollegeService;
import universitymanagementsystem.service.UniversityService;
import universitymanagementsystem.service.collegeimpl.CollegeServiceImpl;
import universitymanagementsystem.service.universityimpl.UniversityServiceImpl;

public class UniversityManagementApp {
	private static Scanner t=new Scanner(System.in);
	private static UniversityService serv=new UniversityServiceImpl();
	private static CollegeService ser=new CollegeServiceImpl();
	private static int s=0;
	public static void main(String args[])
	{
		do {System.out.println("1.To Add University\n2.To Add college\n3.To get all colleges\n4.To get All Universities\n5.Get College"
				+ "By University\n6.To delete a college\n7.To delete a University\n8.To Exit\nPlease enter your choice:");
		  int ch=t.nextInt();
		  switch (ch) {
		case 1:addUniversity();

			break;
		case 2:addCollege();

			break;
		case 3:getAllColleges();

			break;
		case 4:getAllUniversities();

			break;
		case 5:getCollegeByUniversityId();

			break;
		case 6:deleteCollege();

			break;
		case 7:deleteUniversity();

			break;
		case 8:s=1;

			break;
		default:System.out.println("Invalid Choice:");
			break;
		}
		  
			
		}while(s!=1);
	}
	private static void deleteUniversity() {
		System.out.println("Enter University Id:");
		int uid=t.nextInt();
		try {
			boolean check=serv.checkUniversity(uid);
			try{ if(check==false)
			{
				throw new NoSuchUniversityException("University Not Exists:");
			}
			else {
				serv.deleteUniversity(uid);
			}
			}
			catch(NoSuchUniversityException e)
			{
				e.printStackTrace();
			}
		} catch (UniversityServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private static void deleteCollege() {
		System.out.println("Enter college Id:");
		int cid=t.nextInt();
		try {
			boolean check=ser.checkCollege(cid);
			try {
			if(check==false)
			{
				throw new NoSuchCollegeException("College is already Deleted:");
			}
			else {
				ser.deleteCollege(cid);
			}
			
			}
			catch(NoSuchCollegeException e)
			{
				e.printStackTrace();
			}
		} catch (CollegeServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	private static void getCollegeByUniversityId() {
		// TODO Auto-generated method stub
		System.out.println("Enter UID");
		List<College> list;
		int uid=t.nextInt();
		try {
			boolean check =serv.checkUniversity(uid);
			try {
				if(check==false)
				{
					throw new NoSuchUniversityException("Invalid UID:");
				}
				else {list=ser.getColleges(uid);
				for (College college : list) {
					System.out.println(college);
					
				}
					
				}
			}
			catch(NoSuchUniversityException | CollegeServiceException e)
			{
				e.printStackTrace();
			}
		} catch (UniversityServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	private static void getAllUniversities() {
		List<University> li=new ArrayList<>();
		try {
			li=serv.getAllUniversities();
			for (University university : li) {
			   System.out.println(university.getUniversityId()+" "+university.getUniversityName());
			}
		} catch (UniversityServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub
		
	}
	private static void getAllColleges() {
		List<College> li=new ArrayList<>();
		try {
			li=ser.getAllColleges();
			for (College college : li) {
				System.out.println(college.getCollegeId()+" "+college.getCollegeName()+" "+college.getCollegeRating()+" "+college.getUID());
			}
		} catch (CollegeServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	private static void addCollege() {
		College c=new College();
		System.out.println("Enter College Id:");
		int cid=t.nextInt();
		c.setCollegeId(cid);
		t.nextLine();
		System.out.println("Enter collegename:");
		String cname=t.nextLine();
		 try {
			boolean check =ser.checkCollege(cname);
			try {
				if(check==true)
				{
					throw new DuplicateCollegeNameException("College is already there:");
				}
				else {
					c.setCollegeName(cname);
				}
			}
			catch(DuplicateCollegeNameException e)
			{
				e.printStackTrace();
			}
		} catch (CollegeServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		System.out.println("Enter The ratings");
		double crating=t.nextDouble();
		try {
			if(crating<0 ||crating>10)
			{
				throw new RatingOutOfBoundException("Invalid rating:");
			}
			else {
				c.setCollegeRating(crating);
				
			}
		}
		catch(RatingOutOfBoundException e){
			e.printStackTrace();
			
		}
		System.out.println("Enter the UID:");
		int UID=t.nextInt();
		c.setUID(UID);
		
	}
	private static void addUniversity() {
		University uni=new University();
	    System.out.println("Enter the University Id");
	    int uid=t.nextInt();
	    uni.setUniversityId(uid);
	    t.nextLine();
	    
	    System.out.println("Enter university name:");
	    String uname=t.nextLine();
	    
	    try {
	    	boolean check=serv.checkUniversity(uname);
	    	try {
	    		if( check==true)
	    		{
	    			throw new DuplicateUniversityNameException("This University is Already Present");
	    		}
	    		else {
	    			uni.setUniversityName(uname);
	    		}
	    	}
	    	catch(DuplicateUniversityNameException e)
	    	{
	    		e.printStackTrace();
	    	}
	    }
	    catch(UniversityServiceException e)
	    {
	    	e.printStackTrace();
	    
	    }
	    try {
			serv.addUniversity(uni);
		} catch (UniversityServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		
	}

}

