package universitymanagementsystem.utility;

public interface DbConnectivity {

}
