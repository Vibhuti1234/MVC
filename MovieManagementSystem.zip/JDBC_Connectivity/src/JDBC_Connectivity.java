
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
public class JDBC_Connectivity {
	public static void main(String args[]) throws Exception
	{  String url="jdbc:mysql://localhost:3306/vibhuti?useSSL=false";
	    String uname="root";
	    String pass="Welcome123";
	    String query2="insert into employees  values (1007,23005,505,'krishna','Hari','good@gmail.com')";
	    String query="select * from employees";
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection(url,uname,pass);
		PreparedStatement pt=con.prepareStatement(query2);
		int count=pt.executeUpdate();
		
		System.out.println(count+" RowsAffected");
		Statement st=con.createStatement();
		ResultSet rt=st.executeQuery(query);
		String name="";
		while(rt.next())
		{ 
			name =rt.getInt(1)+" : "+rt.getInt(2)+" : "+rt.getInt(3)+" : "+rt.getString(4)+" : "+rt.getString(5)+" : "+rt.getString(6);
			System.out.println(name);
		}
		st.close();
		con.close();
	
	}

}
