import java.sql.*;
public class jdbcConnection {
	public static void main(String args[]) throws Exception
	{  String url="jdbc:mysql://localhost:3306/vibhuti?useSSL=false";
	    String uname="root";
	    String pass="Welcome123";
	    String query="select Email from employees where emp_id=1001";
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection(url,uname,pass);
		Statement st=con.createStatement();
		ResultSet rt=st.executeQuery(query);
		rt.next();
		String name =rt.getString("Email");
		System.out.println(name);
		st.close();
		con.close();
	
	}

}
