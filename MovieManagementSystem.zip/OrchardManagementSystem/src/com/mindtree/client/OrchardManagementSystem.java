package com.mindtree.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import com.mindtree.entity.Capability;
import com.mindtree.entity.MindtreeMind;
import com.mindtree.entity.Track;

public class OrchardManagementSystem {
	public static void main(String args[])
	{
		Scanner t=new Scanner(System.in);
		System.out.println("Give The Number Of Track:");
		int n=t.nextInt();
		HashSet<Track> hs=new HashSet<Track>();
		for(int i=0;i<n;i++)
		{
            System.out.println("Give trackid of Track Number "+(i+1));
            int trackId=t.nextInt();
            t.nextLine();
            System.out.println("Give The Track Name of Track "+(i+1));
            String trackName=t.nextLine();
            System.out.println("Enter The Number of Capabilities for Track Number "+(i+1));
            int cno=t.nextInt();
            Set<Capability> capability=new HashSet<Capability>();
            for(int j=0;j<cno;j++)
            {
            	System.out.println("Enter The Id of Capability Number "+(j+1)+"Under The Track Number "+(i+1));
            	int capabilityId=t.nextInt();
            	t.nextLine();
            	System.out.println("Enter The Name of Capability Number "+(j+1)+"Under The Track Number "+(i+1));
            	String capabilityName=t.nextLine();
            	System.out.println("Enter The Number of Kos Under The Capability Number "+(j+1));
            	int nko=t.nextInt();
            	t.nextLine();
            	List<String> Kos=new ArrayList();
            	for(int k=0;k<nko;k++)
            	{
            		System.out.println("Enter The Ko Number "+(k+1)+" Under The Capability Number "+(j+1));
            		String Ko=t.nextLine();
            		Kos.add(Ko);
            	}
            	Capability ob=new Capability(capabilityId,capabilityName,Kos);
            	capability.add(ob);
            	
            }
            System.out.println("Enter the Number Of leads Under the Track"+(i+1));
            int nL=t.nextInt();
            t.nextLine();
            HashMap<MindtreeMind,List<MindtreeMind>> h=new HashMap<MindtreeMind,List<MindtreeMind>>();
            for(int l=0;l<nL;l++)
            {
            	System.out.println("Enter The MID  of Lead  "+(l+1)+"Under The Track Number "+(i+1));
            	String lId=t.nextLine();
            	System.out.println("Enter The name of Lead "+(l+1)+"Under The Track Number "+(i+1));
            	String lName=t.nextLine();
            	System.out.println("Enter The Role:");
            	String role=t.nextLine();
            	MindtreeMind ob1=new MindtreeMind(lId,lName,role);
            	
            	System.out.println("Enter The Number of Mindtree Minds Under The Lead"+(l+1));
            	int nmm=t.nextInt();
            	t.nextLine();
            	List<MindtreeMind> li=new ArrayList<MindtreeMind>();
            	for(int a=0;a<nmm;a++)
            	{
            		System.out.println("Enter The Mid Of MindtreeMind Number "+(a+1)+"Under The Lead "+(l+1)+"Under The Track "+(i+1));
            		String mId=t.nextLine();
            		System.out.println("Enter The Name Of MindtreeMind Number "+(a+1)+"Under The Lead "+(l+1)+"Under The Track "+(i+1));
            		String mName=t.nextLine();
            		System.out.println("Enter The Role:");
            		String mrole=t.nextLine();
            		MindtreeMind ob2=new MindtreeMind(mId,mName,mrole);
            		li.add(ob2);
            	}
            	h.put(ob1, li);
            		
            	
            }
            Track tr=new Track(trackId,trackName,capability,h);
            hs.add(tr);
            	
            }
		for(Track tra:hs) {
			System.out.println(tra);
		}
            
            
		}
		
	}

