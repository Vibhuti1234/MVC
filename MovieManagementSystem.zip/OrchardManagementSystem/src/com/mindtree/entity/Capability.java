package com.mindtree.entity;

import java.util.List;

public class Capability {
	private int capabilityId;
	private String capabilityName;
	private List<String> Kos;
	public Capability(int capabilityId, String capabilityName, List<String> kos) {
		super();
		this.capabilityId = capabilityId;
		this.capabilityName = capabilityName;
		Kos = kos;
	}
	public int getCapabilityId() {
		return capabilityId;
	}
	public String getCapabilityName() {
		return capabilityName;
	}
	public List<String> getKos() {
		return Kos;
	}
	@Override
	public String toString() {
		return "Capability [capabilityId=" + capabilityId + ", capabilityName=" + capabilityName + ", Kos=" + Kos + "]";
	}
	
	
 
}
