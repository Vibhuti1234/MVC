package com.mindtree.entity;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Track {
	private int trackId;
	private String trackName;
	private Set<Capability> s;
	private Map<MindtreeMind,List<MindtreeMind>> m;
	public Track(int trackId, String trackName, Set<Capability> s, Map<MindtreeMind, List<MindtreeMind>> m) {
		super();
		this.trackId = trackId;
		this.trackName = trackName;
		this.s = s;
		this.m = m;
	}
	public int getTrackId() {
		return trackId;
	}
	public String getTrackName() {
		return trackName;
	}
	public Set<Capability> getS() {
		return s;
	}
	public Map<MindtreeMind, List<MindtreeMind>> getM() {
		return m;
	}
	@Override
	public String toString() {
		return "Track [trackId=" + trackId + ", trackName=" + trackName + ", s=" + s + ", m=" + m + "]";
	}
	
}
