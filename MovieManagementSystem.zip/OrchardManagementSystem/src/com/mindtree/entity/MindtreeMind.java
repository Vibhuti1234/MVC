package com.mindtree.entity;

import java.util.List;

public class MindtreeMind {
	private String MID;
	private String name;
	private String role;
	public MindtreeMind(String mID, String name, String role) {
		super();
		MID = mID;
		this.name = name;
		this.role = role;
	}
	public String getMID() {
		return MID;
	}
	public String getName() {
		return name;
	}
	
	public String getRole() {
		return role;
	}
	@Override
	public String toString() {
		return "MindtreeMind [MID=" + MID + ", name=" + name + ", role=" + role + "]";
	}

	

}