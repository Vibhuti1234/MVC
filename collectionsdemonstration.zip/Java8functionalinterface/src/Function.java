import java.util.List;
import java.util.Set;

@FunctionalInterface
public interface Function {
	List<User> usersFiltered();
}
