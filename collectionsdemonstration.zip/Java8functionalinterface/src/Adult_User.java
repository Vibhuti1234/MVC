import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;



public class Adult_User {
	public static void main(String[] args) {
		
	List<User> users=new ArrayList<User>();
	users.add(new User(1,"Shyam",21));
	users.add(new User(2,"Shyam",60));
	users.add(new User(3,"Shyam",61));
	users.add(new User(4,"Shyam",67));
	users.add(new User(5,"Shyam",63));
	users.add(new User(6,"Shyam",81));
	users.add(new User(7,"Shyam",69));
	users.add(new User(8,"Shyam",23));
	users.add(new User(9,"Shyam",24));
	users.add(new User(10,"Shyam",25));
	users.add(new User(11,"Shyam",57));
	List<User> users1=users.stream().filter(i->i.getAge()>=60).collect(Collectors.toList());
	Collections.sort(users1,Collections.reverseOrder());
	Function f=()->users1; 
	f.usersFiltered().stream().forEach(i->{System.out.println(i.getAge()+" "+i.getUserId()+" "+i.getUserName());});





	}

	

}
