
public class Adult {
private int adultId;
private String adultName;
private int adultAge;
public Adult() {
	super();
	// TODO Auto-generated constructor stub
}
public Adult(int adultId, String adultName, int adultAge) {
	super();
	this.adultId = adultId;
	this.adultName = adultName;
	this.adultAge = adultAge;
}
public int getAdultId() {
	return adultId;
}
public void setAdultId(int adultId) {
	this.adultId = adultId;
}
public String getAdultName() {
	return adultName;
}
public void setAdultName(String adultName) {
	this.adultName = adultName;
}
public int getAdultAge() {
	return adultAge;
}
public void setAdultAge(int adultAge) {
	this.adultAge = adultAge;
}
@Override
public String toString() {
	return "Adult [adultId=" + adultId + ", adultName=" + adultName + ", adultAge=" + adultAge + "]";
}

}
