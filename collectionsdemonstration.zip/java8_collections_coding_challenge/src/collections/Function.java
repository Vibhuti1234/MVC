package collections;

import java.util.List;
import java.util.Set;

@FunctionalInterface
public interface Function {
  List<Game> gamesFiltered();
	 static int averagePrice(List<Game> games) 
	    { 
		 int sum=games.stream().reduce(0,(a,b)->a+(int)b.getGamePrice(),Integer::sum);
		 sum=sum/games.size();
		 return sum;
		 

	    } 

}
