package collections;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.TreeSet;

public class PersonDataTest {
	public static void main(String[] args) {
		List<String> h1=new ArrayList<String>();
		h1.add("Reading");
		h1.add("Dancing");
		List<String> h2=new ArrayList<String>();
		h2.add("Writing");
		h2.add("Boxing");
	    TreeSet<Creater>  c1=new TreeSet<Creater>(); 
		c1.add(new Creater(1,"Ubisoft",h1));
		c1.add(new Creater(2,"UbiX",h1));
	    TreeSet<Creater>  c2=new TreeSet<Creater>(); 
		c2.add(new Creater(3,"Ubisoft",h1));
		c2.add(new Creater(4,"Saleem",h1));
	    TreeSet<Creater>  c3=new TreeSet<Creater>(); 
		c3.add(new Creater(5,"Arnab",h2));
		c3.add(new Creater(6,"Devrekonda",h2));
	    TreeSet<Creater>  c4=new TreeSet<Creater>(); 
		c4.add(new Creater(7,"Ali",h2));
		c4.add(new Creater(8,"Akash",h2));
		TreeMap<Game,TreeSet<Creater>> treeMap1=new TreeMap<>();
		treeMap1.put(new Game(1,"Boxing",56000), c1);
		treeMap1.put(new Game(2,"Kudo",66000), c2);
		treeMap1.put(new Game(3,"Kudo",67000), c3);
		treeMap1.put(new Game(4,"Gymnastics",89000),c4);
		HashMap<Person, TreeMap<Game, TreeSet<Creater>>> hashMap1=new HashMap<>();
		hashMap1.put(new Person(1,"Ali"),treeMap1 );
		 Iterator<Entry<Person, TreeMap<Game, TreeSet<Creater>>>> itr = hashMap1.entrySet().iterator(); 
         
	        while(itr.hasNext()) 
	        { 
	             Entry<Person, TreeMap<Game, TreeSet<Creater>>> entry = itr.next(); 
	             System.out.println("Key = " + entry.getKey() );
	    		 Iterator<Entry<Person, TreeMap<Game, TreeSet<Creater>>>> itr = hashMap1.entrySet().iterator(); 

	                                 
	        } 

		
		
		
    
        /*g1.add(new Game(1,"Boxing",12000,c1));
        g1.add(new Game(2,"Boxing",11000,c2));
        g1.add(new Game(3,"Kudo",13000,c3));
        g1.add(new Game(4,"Judo",10000,c4));
        g1.add(new Game(5,"Kudo",21000,c1));*/
       // persons.add(new Person(1,"Syed Ali",g1));     List<Person> persons=new ArrayList<Person>();
   
        /*System.out.println("::::::::::::: All Games ::::::::::::::::");
        System.out.println(":::::::::::::Question 1::::::::::::::");
        List<Game> filteredGames=new ArrayList<Game>();
        TreeMap result=treeMap1.entrySet().stream().filter(i->i.getKey().getGamePrice()>500).collect(Collectors.toMap());
        // treeMap1.stream().forEach(i->{if(i.getGamePrice()>500) {i.getCreaters().stream().forEach(j->{if(j.getCreaterName().equals("Ubisoft")) {filteredGames.add(i);}});}});
        System.out.println(":::::::::::::::Question2:::::::::::::::");
        Collections.sort(filteredGames,Collections.reverseOrder());
        Function f=()->filteredGames;
       f.gamesFiltered().stream().forEach(i->{System.out.println(i.getGameId()+" "+i.getGameName()+" "+i.getGamePrice());});
        Function.averagePrice(g1);
       System.out.println(Function.averagePrice(g1));


*/

		
		
		
		
	}

}
