package collections;

import java.util.List;

public class Creater implements Comparable<Creater> {
	private int createrId;
	private String createrName;
	private List<String> createrHobbies;
	public Creater() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Creater(int createrId, String createrName, List<String> createrHobbies) {
		super();
		this.createrId = createrId;
		this.createrName = createrName;
		this.createrHobbies = createrHobbies;
	}
	public int getCreaterId() {
		return createrId;
	}
	public void setCreaterId(int createrId) {
		this.createrId = createrId;
	}
	public String getCreaterName() {
		return createrName;
	}
	public void setCreaterName(String createrName) {
		this.createrName = createrName;
	}
	public List<String> getCreaterHobbies() {
		return createrHobbies;
	}
	public void setCreaterHobbies(List<String> createrHobbies) {
		this.createrHobbies = createrHobbies;
	}
	@Override
	public String toString() {
		return "Creater [createrId=" + createrId + ", createrName=" + createrName + ", createrHobbies=" + createrHobbies
				+ "]";
	}
	@Override
	public int compareTo(Creater e) {
		// TODO Auto-generated method stub
		return createrName.compareTo(e.createrName);
	}
	

}
