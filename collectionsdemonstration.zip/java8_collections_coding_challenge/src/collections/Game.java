package collections;

import java.util.List;
import java.util.TreeSet;

public class Game implements Comparable<Object>{
	private int gameId;
	private String gameName;
	private double gamePrice;
	
	
	public Game() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Game(int gameId, String gameName, double gamePrice) {
		super();
		this.gameId = gameId;
		this.gameName = gameName;
		this.gamePrice = gamePrice;
		
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((gameName == null) ? 0 : gameName.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Game other = (Game) obj;
		if (gameName == null) {
			if (other.gameName != null)
				return false;
		} else if (!gameName.equals(other.gameName))
			return false;
		return true;
	}
	public int getGameId() {
		return gameId;
	}
	public void setGameId(int gameId) {
		this.gameId = gameId;
	}
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	public double getGamePrice() {
		return gamePrice;
	}
	public void setGamePrice(double gamePrice) {
		this.gamePrice = gamePrice;
	}
	
	
	public int compareTo(Object o1) {

	        Game e = (Game)o1;
	        int inameComaprison = gameName.compareTo(e.gameName);
	        if (inameComaprison == 0)//Salaries are equal use name as comparison criteria
	        {
	            //lhs name comparison with rhs name
	            return Double.compare(this.gamePrice, e.gamePrice);
	        }
	        //Now if salaries are not equal, return comparison of salries
	        return inameComaprison;

	    }


	@Override
	public String toString() {
		return "Game [gameId=" + gameId + ", gameName=" + gameName + ", gamePrice=" + gamePrice + "]";
	}


	
	
	

}
