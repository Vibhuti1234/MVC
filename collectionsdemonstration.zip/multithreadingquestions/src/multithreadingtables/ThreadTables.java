package multithreadingtables;
class Tables{
	private int count=1;
	private int i=1;
	private int j=10;
	synchronized void ascendingTable() throws InterruptedException
	{
		while(i<=5)
		{
			if(count<=5)
			{
				System.out.println("Thread 1:");
				System.out.println("4 X"+i+"="+4*i);
				System.out.println("---------------------------------");
				i++;
				count++;
				notify();
			}
			else {
				
					wait();
				
			}
		}
	}
		synchronized void  descendingTable() throws InterruptedException {
			while(j>=5)
			{if(count<=10)
			{
				System.out.println("Thread 1:");
				System.out.println("4 X"+i+"="+4*i);
				System.out.println("---------------------------------");
				j--;
				count++;
				notify();
			}
			else {
				
					wait();
			
			}
				
			}
		}
			
		}
	


public class ThreadTables {
	public static void main(String[] args) throws InterruptedException {
		Tables tables=new Tables();
		Thread t1=new Thread(()-> {
			try {
				tables.ascendingTable();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		Thread t2=new Thread(()-> {
			try {
				tables.descendingTable();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		System.out.println("::::::::::::::::::");
		t1.start();
		t2.start();
	}

}
