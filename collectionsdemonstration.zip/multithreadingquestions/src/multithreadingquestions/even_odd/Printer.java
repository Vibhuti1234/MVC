package multithreadingquestions.even_odd;

public class Printer {

	public void printEven(int number) {
		// TODO Auto-generated method stub
		
	}

	public void printOdd(int number) {
		// TODO Auto-generated method stub
		
	}

}
