package ascdesc;

class AscDescThread
{
	private int num1=5;
	private int num2=1;
	private boolean b=true;
	synchronized void ThreadA() throws InterruptedException
	{while(num1>0)
	{ if(b==true)
	{
		System.out.println(num1);
		b=false;
		notify();
		num1--;
	}
	else {
		wait();
	}
		
	}
		
		
	}
	synchronized void ThreadB() throws InterruptedException
	{while(num2<=5)
	{ if(b==false)
	{
		System.out.println(num2);
		b=true;
		notify();
		num2++;
	}
	else {
		wait();
	}
		
	}
		
		
	}
	
}
public class AscDesc {
	public static void main(String[] args) {
		AscDescThread ascdesc=new AscDescThread();
		new Thread() {
			public void run() {
				try {
					ascdesc.ThreadA();
				} catch (InterruptedException e) {

					e.printStackTrace();
				}

			}
		}.start();

		new Thread() {
			public void run() {
				try {
					ascdesc.ThreadB();
				} catch (InterruptedException e) {

					e.printStackTrace();
				}

			}
		}.start();

		
	}

}
