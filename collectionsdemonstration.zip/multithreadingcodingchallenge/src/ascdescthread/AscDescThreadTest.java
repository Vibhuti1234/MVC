package ascdescthread;
class AscDescThreads{
	private int n1=2;
	private int n2=2;
	private int i=5;
	private int j=1;
	
	private boolean b=true;
	synchronized void ThreadA() throws InterruptedException
	{
		while(n1!=0)
		{
			if(b==true)
			{    if(i==5) {
				for ( ; i>= 1; i--) {
					
					System.out.println("ThreadA : "+i);
				}}
			else {
				for ( i =1 ; i <=5; i++) {
					System.out.println("ThreadA : "+i);
				}
			}
				b=false;
				notify();
				n1--;
			}
			else {
				wait();
			}
		}
	}
	synchronized void ThreadB() throws InterruptedException
	{
		while(n2!=0)
		{
			if(b==false)
			{if(j==1) {
				for (; j<=5; j++) {
					
					System.out.println("Thread B : "+j);
				}
			}
			else {
				for(j=5;j>=1;j--)
				{
					System.out.println("Thread B :"+j);
				}
			}
				b=true;
				notify();
				n2--;
			}
			else {
				wait();
			}
		}
	}
}
public class AscDescThreadTest {
	public static void main(String[] args) {
		AscDescThreads ascDescThreads=new AscDescThreads();
		new Thread() {
			public void run() {
				try {
					ascDescThreads.ThreadA();
				} catch (InterruptedException e) {

					e.printStackTrace();
				}

			}
		}.start();

		new Thread() {
			public void run() {
				try {
					ascDescThreads.ThreadB();
				} catch (InterruptedException e) {

					e.printStackTrace();
				}

			}
		}.start();

		
	}

}
