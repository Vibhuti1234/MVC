package collectionsdemo1;

public class City {
	private String cityName;
	

}
