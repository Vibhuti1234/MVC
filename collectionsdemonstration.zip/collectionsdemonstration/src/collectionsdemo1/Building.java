package collectionsdemo1;

import java.util.Set;

public class Building {
private int buildingId;
private String buildingName;
private Set<User> users;
public Building() {
	super();
	// TODO Auto-generated constructor stub
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((buildingName == null) ? 0 : buildingName.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Building other = (Building) obj;
	if (buildingName == null) {
		if (other.buildingName != null)
			return false;
	} else if (!buildingName.equals(other.buildingName))
		return false;
	return true;
}

public Building(int buildingId, String buildingName, Set<User> users) {
	super();
	this.buildingId = buildingId;
	this.buildingName = buildingName;
	this.users = users;
}
public int getBuildingId() {
	return buildingId;
}
public void setBuildingId(int buildingId) {
	this.buildingId = buildingId;
}
public String getBuildingName() {
	return buildingName;
}
public void setBuildingName(String buildingName) {
	this.buildingName = buildingName;
}
public Set<User> getUsers() {
	return users;
}
public void setUsers(Set<User> users) {
	this.users = users;
}
@Override
public String toString() {
	return "Building [buildingId=" + buildingId + ", buildingName=" + buildingName + ", users=" + users + "]";
}



}
