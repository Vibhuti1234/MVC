package collectionsdemonstration;

public class Building {
private int buildingId;
private String buildingName;
public Building() {
	super();
	// TODO Auto-generated constructor stub
}
public Building(int buildingId, String buildingName) {
	super();
	this.buildingId = buildingId;
	this.buildingName = buildingName;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((buildingName == null) ? 0 : buildingName.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Building other = (Building) obj;
	if (buildingName == null) {
		if (other.buildingName != null)
			return false;
	} else if (!buildingName.equals(other.buildingName))
		return false;
	return true;
}
public int getBuildingId() {
	return buildingId;
}
public void setBuildingId(int buildingId) {
	this.buildingId = buildingId;
}
public String getBuildingName() {
	return buildingName;
}
public void setBuildingName(String buildingName) {
	this.buildingName = buildingName;
}
@Override
public String toString() {
	return "Building [buildingId=" + buildingId + ", buildingName=" + buildingName + "]";
}


}
