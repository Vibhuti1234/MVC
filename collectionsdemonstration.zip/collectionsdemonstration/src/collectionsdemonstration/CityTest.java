package collectionsdemonstration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CityTest {
public static void main(String[] args) {
	City city=new City();
	List<User> users=new ArrayList<User>();
	users.add(new User(1,"Vibhuti"));
	users.add(new User(2,"Gaurav"));
	users.add(new User(3,"Prateek"));
	users.add(new User(1,"Vibhuti"));
	Collections.sort(users);
	Set<User> user=new HashSet<User>(users);
	
	List<User> users1=new ArrayList<User>();
	users1.add(new User(1,"Vikas"));
	users1.add(new User(2,"Gauri"));
	users1.add(new User(3,"Prameshwar"));
	users1.add(new User(1,"Vikas"));
	Collections.sort(users1);
	Set<User> user1=new HashSet<User>(users1);
	
	
	
	/*Set<Building> buildings=new HashSet<Building>();
	buildings.add(new Building(1,"A-Block"));
	buildings.add(new Building(2,"B-Block"));
	buildings.add(new Building(3,"C-Block"));*/
	
	
	city.setCityName("Bhubneshwar");
	
	/*System.out.println(city.getCityName());
	city.getBuildings().stream().forEach(i->{System.out.println(i);});
	city.getUsers().stream().forEach(i->{System.out.println(i);});*/
	Map<City,Map<Building, Set<User>>> cityMap=new HashMap<City,Map<Building, Set<User>>>();
	Map<Building,Set<User>> maps=new HashMap<Building,Set<User>>();
	maps.put(new Building(1, "Champa"),user);
	maps.put(new Building(2, "Chameli"),user1);
	cityMap.put(city, maps);
	cityMap.entrySet().forEach(entry->{
	    System.out.println(entry.getKey() );  
	    entry.getValue().entrySet().forEach(i->{System.out.println(i.getKey()+" "+i.getValue());});
	    
	 });
	
	

}
}
