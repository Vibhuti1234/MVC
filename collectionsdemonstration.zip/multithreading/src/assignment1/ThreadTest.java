package assignment1;
class ThreadA implements Runnable
{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for (int i = 1; i <=25; i++) {
			System.out.println(i);
			
		}
		
	}
	
}
class ThreadB implements Runnable
{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for (int i = 1; i <=25; i++) {
			System.out.println(i);
			
		}
		
	}
	
}

public class ThreadTest {
	public static void main(String[] args) {
		ThreadA threadA=new ThreadA();
		Thread t1=new Thread(threadA);
		t1.start();
		ThreadB threadB=new ThreadB();
		Thread t2=new Thread(threadB);
		t2.start();
		
		
		
	}

}
