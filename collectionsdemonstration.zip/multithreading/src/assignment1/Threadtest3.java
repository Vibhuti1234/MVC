package assignment1;
class ThreadD implements Runnable
{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		for (int i = 0; i < 10; i++) {
			ticketBooking();
			try {
				Thread.sleep(2);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			ticketShowing();

		}
		
	}
	public void ticketBooking()
	{
		
			System.out.println("Ticket Booked");
			
		
	}
	public void ticketShowing()
	{
		System.out.println("Ticket Shown");
		
	
		
	}
}
public class Threadtest3 {
	public static void main(String[] args) {
		ThreadD threadD=new ThreadD();
		Thread t=new Thread(threadD);
		t.start();
	}

}
