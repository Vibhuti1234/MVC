package assignment1;
class ThreadC implements Runnable{
	@Override
	public void run() {
		// TODO Auto-generated method stub
		Task1();
		Task2();
		Task3();
		
	}	
	public void Task1()
	{for (int i = 0; i < 5; i++) {
		System.out.println("Task1 Is Executed:");

	}
	}
	public void Task2()
	{ for (int i = 0; i < 5; i++) {
		System.out.println("Task2 Is Executed:");

		
	}
	}	
	public void Task3()
	{for (int i = 0; i < 5; i++) {
		System.out.println("Task3 Is Executed:");

	}
	}
	
	
}
public class ThreadTest2 {
	public static void main(String[] args) {
		ThreadC threadC=new ThreadC();
		Thread t1=new Thread(threadC);
		t1.start();
		
	}

}
