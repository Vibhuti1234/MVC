package assignment1;
 class Mult{
	boolean temp=true;

int mul1=1;
int mul2=10;
	 synchronized void fun1() throws InterruptedException {
		 
		  {
		
			 while(mul2<=5)
			 {
				 if(mul2%2==0)
				 {
					 
				 
				 System.out.println(4*mul1+"Thread1");	
					mul1++;
					temp=false;
					
					notify();
					
			
				 }
				 else
				{
					
				wait();
				 }
			 }
		  }
				
			}
			
	 synchronized void fun2() throws InterruptedException {
		 
		  {
		
			 while(mul1<=5)
			 {
				 if(mul1%2!=0)
				 {
					 
				 
				 System.out.println(4*mul1+"Thread1");	
					mul1++;
					temp=false;
					
					notify();
					
			
				 }
				 else
				{
					
				wait();
				 }
			 }
		  }
				
			}
		
public class ThreadTests {
	public static void main(String args[]) {
	
		Mult mult=new Mult();
		new Thread() {
			@Override
			public void run() {
				try {
					mult.fun1();
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
			}
	
	}.start();
	
	new Thread() {
		@Override
		public void run() {
			try {
				mult.fun2();
			}catch(InterruptedException e) {
				e.printStackTrace();
			}
		}

}.start();

	}	
}