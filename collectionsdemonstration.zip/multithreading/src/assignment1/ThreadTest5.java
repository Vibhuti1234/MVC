package assignment1;
class Thread1 implements Runnable
{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
	
}
class Thread2 implements Runnable
{

	@Override
	public void run() {
		
		
	}
	
}


public class ThreadTest5{
	public static void main(String[] args) {
		
	
	ThreadX threadX=new ThreadX();
	Thread t1=new Thread(threadX);
  t1.start();
	ThreadY threadY=new ThreadY();
	Thread t2=new Thread(threadY);
	t2.start();
	}	
	
}
