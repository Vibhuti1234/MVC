package com.mindtree.ChannelGroupManagementSystem.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mindtree.ChannelGroupManagementSystem.dto.ChannelDto;
import com.mindtree.ChannelGroupManagementSystem.dto.ChannelGroupDto;
import com.mindtree.ChannelGroupManagementSystem.dto.ShowDto;
import com.mindtree.ChannelGroupManagementSystem.entity.Channel;
import com.mindtree.ChannelGroupManagementSystem.exception.ChannelGroupChannelShowServiceException;
import com.mindtree.ChannelGroupManagementSystem.service.ChannelGroupChannelService;

@RunWith(org.mockito.junit.MockitoJUnitRunner.class)
@WebMvcTest(AppController.class)
public class AppControllerTest {

	@Autowired
	MockMvc mockMvc;

	@InjectMocks
	AppController appcontroller;

	@Mock
	ChannelGroupChannelService channelGroupChannelService;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(appcontroller).build();
	}

	@Test
	public void testInsertChannelGroup() {
		ChannelGroupDto channelgroupdto = new ChannelGroupDto();
		channelgroupdto.setChannelgoupId(1);
		channelgroupdto.setChannelgroupName("aa");
		channelgroupdto.setChannelgoupId(2);
		channelgroupdto.setChannelgroupName("bb");
		channelgroupdto.setChannelgoupId(3);
		channelgroupdto.setChannelgroupName("cc");
		when(channelGroupChannelService.insertChannelGroupIntoDB(channelgroupdto)).thenReturn(channelgroupdto);
		assertEquals(appcontroller.insertChannelGroup(channelgroupdto), "inserted successfully");
	}

	@Test
	public void testInsertChannel() throws ChannelGroupChannelShowServiceException {
		ChannelDto channeldto = new ChannelDto();
		channeldto.setChannelId(1);
		channeldto.setChannelName("xx");
		channeldto.setPrice(100);
		channeldto.setChannelId(2);
		channeldto.setChannelName("yy");
		channeldto.setPrice(200);
		channeldto.setChannelId(1);
		channeldto.setChannelName("zz");
		channeldto.setPrice(300);
		when(channelGroupChannelService.insertchannelIntoDB(channeldto, 1)).thenReturn(channeldto);
		assertEquals(appcontroller.insertChannel(channeldto, 1).getStatusCodeValue(), 200);
	}

	@Test
	public void testInsertShow() throws ChannelGroupChannelShowServiceException {
		ShowDto showdto = new ShowDto();
		showdto.setShowId(1);
		showdto.setShowName("xy");
		showdto.setShowId(2);
		showdto.setShowName("mn");
		showdto.setShowId(3);
		showdto.setShowName("op");
		when(channelGroupChannelService.insertshowIntoDB(showdto, 1)).thenReturn(showdto);
		assertEquals(appcontroller.insertShow(showdto, 1).getStatusCodeValue(), 200);

	}

	@Test
	public void testGetAllChannels() {
		ChannelDto channeldto = new ChannelDto();
		List<ChannelDto> channelsdto = new ArrayList<>();
		channeldto.setChannelId(1);
		channeldto.setChannelName("mm");
		channeldto.setPrice(300);
		channeldto.setChannelId(2);
		channeldto.setChannelName("nn");
		channeldto.setPrice(400);
		channeldto.setChannelId(1);
		channeldto.setChannelName("oo");
		channeldto.setPrice(500);
		channelsdto.add(channeldto);
		when(channelGroupChannelService.getAllChannels(1)).thenReturn(channelsdto);
		assertEquals(appcontroller.getAllChannels(1), channelsdto);

	}
	
	@Test
	public void testupdateChannel() {
		Channel channel=new Channel();
		channel.setChannelName("gh");
		when(channelGroupChannelService.updateChannel(channel, 1, "gh")).thenReturn(channel);
		assertEquals(appcontroller.updateChannel(channel,1,"gh"),channel);
	}
	
	@Test
	public void testdeleteChannel() {
	Channel channel=new Channel();
	when(channelGroupChannelService.deleteChannelInDB(1)).thenReturn(channel);
	assertEquals(appcontroller.deleteChannel(1),channel);
	}
	
	
	

}
