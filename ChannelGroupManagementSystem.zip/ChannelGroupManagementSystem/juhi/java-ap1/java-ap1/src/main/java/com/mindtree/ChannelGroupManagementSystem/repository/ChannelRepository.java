package com.mindtree.ChannelGroupManagementSystem.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.mindtree.ChannelGroupManagementSystem.entity.Channel;

@Repository
public interface ChannelRepository extends JpaRepositoryImplementation<Channel, Integer>{

}
