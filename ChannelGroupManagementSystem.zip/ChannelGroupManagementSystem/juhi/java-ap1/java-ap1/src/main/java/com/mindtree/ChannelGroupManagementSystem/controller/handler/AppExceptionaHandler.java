package com.mindtree.ChannelGroupManagementSystem.controller.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.ChannelGroupManagementSystem.controller.AppController;
import com.mindtree.ChannelGroupManagementSystem.exception.NoSuchChannelFoundException;
import com.mindtree.ChannelGroupManagementSystem.exception.NoSuchChannelGroupFoundException;

@RestControllerAdvice(assignableTypes = { AppController.class })
public class AppExceptionaHandler {
	
	@ExceptionHandler(NoSuchChannelFoundException.class)
	public ResponseEntity<String> serviceExceptionHandler(NoSuchChannelFoundException e) {
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
	}
	

	@ExceptionHandler(NoSuchChannelGroupFoundException.class)
	public ResponseEntity<String> serviceExceptionHandler(NoSuchChannelGroupFoundException e) {
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
	}
	
	

}
