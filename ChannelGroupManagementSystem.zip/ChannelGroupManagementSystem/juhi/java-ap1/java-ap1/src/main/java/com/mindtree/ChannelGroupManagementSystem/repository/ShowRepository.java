package com.mindtree.ChannelGroupManagementSystem.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.mindtree.ChannelGroupManagementSystem.entity.Show;

@Repository
public interface ShowRepository extends JpaRepositoryImplementation<Show, Integer>{

}
